"""RuneManager - a Deltarune mod manager."""
import sys
import traceback
from pathlib import Path

VERSION = "1.0"

if sys.version_info < (3, 8):
    sys.exit("RuneManager needs Python 3.8 or newer.")

sys.path.insert(0, str(Path(__file__).resolve().parent))

try:
    import tkinter as tk
except ImportError:
    sys.exit("tkinter is missing. Reinstall Python from python.org and keep "
             "'tcl/tk and IDLE' ticked in the installer.")


def main():
    if sys.platform.startswith("win"):
        try:  # crisp text on high-DPI screens
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    root = tk.Tk()
    from ui.app import VesselApp
    VesselApp(root)
    root.mainloop()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        base = (Path(sys.executable).parent if getattr(sys, "frozen", False)
                else Path(__file__).resolve().parent)
        log = base / "crash.log"
        log.write_text(traceback.format_exc(), encoding="utf-8")
        try:
            from tkinter import messagebox
            messagebox.showerror("RuneManager crashed", f"Details saved to:\n{log}")
        except Exception:
            pass
        raise
