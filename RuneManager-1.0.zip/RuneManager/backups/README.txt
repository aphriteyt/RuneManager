RuneManager puts your untouched game files and save backups here.
DON'T DELETE THIS FOLDER - it's how RESTORE puts everything back.
