Put xdelta3.exe in this folder.
Download it from: https://github.com/jmacd/xdelta-gpl/releases
(get the Windows x86_64 zip, rename the .exe inside to xdelta3.exe)
Only needed for .xdelta patch mods.
