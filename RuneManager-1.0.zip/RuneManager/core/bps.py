"""bps patch format (what Flips makes). Spec: byuu's beat v1."""
import os
import struct
import zlib
from pathlib import Path


class BPSError(Exception):
    pass


def crc32_file(path, cache=None):
    """CRC32 of a file (cached by size + modified time, big data.win files are slow)."""
    path = Path(path)
    st = path.stat()
    key = "crc:" + str(path)
    if cache is not None:
        hit = cache.get(key)
        if hit and hit[0] == st.st_size and abs(hit[1] - st.st_mtime) < 0.001:
            return hit[2]
    crc = 0
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(4 * 1024 * 1024), b""):
            crc = zlib.crc32(chunk, crc)
    crc &= 0xFFFFFFFF
    if cache is not None:
        cache[key] = [st.st_size, st.st_mtime, crc]
    return crc


def read_footer(patch_path):
    """(source_crc, target_crc, source_size) of a .bps without applying it."""
    with open(patch_path, "rb") as f:
        head = f.read(32)
        if head[:4] != b"BPS1":
            raise BPSError(f"{Path(patch_path).name} isn't a valid .bps patch.")
        f.seek(-12, os.SEEK_END)
        src_crc, tgt_crc, _ = struct.unpack("<III", f.read(12))
    source_size, _ = _varint(head, 4)
    return src_crc, tgt_crc, source_size


def _varint(buf, pos):
    data, shift = 0, 1
    while True:
        x = buf[pos]
        pos += 1
        data += (x & 0x7F) * shift
        if x & 0x80:
            return data, pos
        shift <<= 7
        data += shift


# TODO: could stream this instead of loading whole files, but data.win is
# only ~150MB worst case and it runs in about a second
def apply(source_path, patch_path, out_path):
    """Patch source -> out. Verifies every checksum; raises BPSError on any mismatch."""
    patch = Path(patch_path).read_bytes()
    if len(patch) < 19 or patch[:4] != b"BPS1":
        raise BPSError(f"{Path(patch_path).name} isn't a valid .bps patch.")
    src_crc, tgt_crc, patch_crc = struct.unpack("<III", patch[-12:])
    if zlib.crc32(patch[:-4]) & 0xFFFFFFFF != patch_crc:
        raise BPSError("The patch file is damaged (checksum failed). Re-download the mod.")

    source = Path(source_path).read_bytes()
    if zlib.crc32(source) & 0xFFFFFFFF != src_crc:
        raise BPSError("This patch was made for a different version of the game file.")

    pos = 4
    source_size, pos = _varint(patch, pos)
    target_size, pos = _varint(patch, pos)
    meta_size, pos = _varint(patch, pos)
    pos += meta_size
    if source_size != len(source):
        raise BPSError("Source file size doesn't match the patch.")

    target = bytearray(target_size)
    out = 0                      # write position in target
    src_rel = 0                  # SourceCopy cursor
    tgt_rel = 0                  # TargetCopy cursor
    end = len(patch) - 12
    while pos < end:
        data, pos = _varint(patch, pos)
        cmd, length = data & 3, (data >> 2) + 1
        if cmd == 0:                                   # SourceRead
            target[out:out + length] = source[out:out + length]
        elif cmd == 1:                                 # TargetRead
            target[out:out + length] = patch[pos:pos + length]
            pos += length
        elif cmd == 2:                                 # SourceCopy
            d, pos = _varint(patch, pos)
            src_rel += -(d >> 1) if d & 1 else (d >> 1)
            target[out:out + length] = source[src_rel:src_rel + length]
            src_rel += length
        else:                                          # TargetCopy (may overlap)
            d, pos = _varint(patch, pos)
            tgt_rel += -(d >> 1) if d & 1 else (d >> 1)
            dist = out - tgt_rel
            if dist >= length or dist <= 0:
                target[out:out + length] = target[tgt_rel:tgt_rel + length]
            else:  # overlapping copy = the last `dist` bytes repeated
                pattern = bytes(target[tgt_rel:out])
                target[out:out + length] = (pattern * (length // dist + 1))[:length]
            tgt_rel += length
        out += length
        if out > target_size:
            raise BPSError("The patch is corrupt (wrote past the end).")

    if zlib.crc32(target) & 0xFFFFFFFF != tgt_crc:
        raise BPSError("Patched result failed its checksum - nothing was changed.")
    tmp = Path(str(out_path) + ".part")
    tmp.write_bytes(target)
    os.replace(tmp, out_path)
