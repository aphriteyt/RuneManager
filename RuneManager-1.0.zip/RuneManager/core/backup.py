"""Backups: save snapshots + the untouched game files."""
import hashlib
import json
import os
import shutil
import time
from pathlib import Path

from . import config, paths

MAX_SNAPSHOTS = 25
VANILLA_MANIFEST = config.VANILLA_DIR / "manifest.json"


# ==========================================================
def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def snapshot_saves(reason="manual"):
    """Copy the whole save folder into a new timestamped snapshot. Returns its name or None."""
    src = paths.save_dir()
    if not src.exists():
        return None
    files = [p for p in src.rglob("*") if p.is_file()]
    if not files:
        return None
    name = time.strftime("%Y-%m-%d_%H-%M-%S") + "_" + reason.replace(" ", "-")
    dest = config.SAVE_SNAP_DIR / name
    n = 1
    while dest.exists():
        n += 1
        dest = config.SAVE_SNAP_DIR / f"{name}_{n}"
    manifest = {}
    for f in files:
        rel = f.relative_to(src).as_posix()
        out = dest / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(f, out)
        manifest[rel] = _sha256(out)
    config.write_json(dest / "_manifest.json",
                      {"reason": reason, "time": time.time(), "files": manifest})
    _prune_snapshots()
    return dest.name


def list_snapshots():
    """Newest first: list of (name, reason, file_count)."""
    out = []
    if not config.SAVE_SNAP_DIR.exists():
        return out
    for d in sorted(config.SAVE_SNAP_DIR.iterdir(), reverse=True):
        if d.is_dir():
            man = config.read_json(d / "_manifest.json", {})
            out.append((d.name, man.get("reason", "?"), len(man.get("files", {}))))
    return out


def verify_snapshot(name):
    """Check every file still matches its recorded hash. Returns list of problems."""
    d = config.SAVE_SNAP_DIR / name
    man = config.read_json(d / "_manifest.json", None)
    if not man:
        return ["Snapshot manifest missing."]
    problems = []
    for rel, digest in man["files"].items():
        f = d / rel
        if not f.exists():
            problems.append(f"missing: {rel}")
        elif _sha256(f) != digest:
            problems.append(f"corrupted: {rel}")
    return problems


def restore_snapshot(name):
    """Restore a snapshot over the live save folder (current saves are snapshotted first)."""
    problems = verify_snapshot(name)
    if problems:
        raise RuntimeError("Backup failed its integrity check:\n" + "\n".join(problems))
    if paths.is_game_running():
        raise RuntimeError("Close DELTARUNE first - the game rewrites saves while running.")
    snapshot_saves("before-restore")
    src = config.SAVE_SNAP_DIR / name
    dest = paths.save_dir()
    dest.mkdir(parents=True, exist_ok=True)
    man = config.read_json(src / "_manifest.json", {})
    for rel in man["files"]:
        out = dest / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src / rel, out)
    return len(man["files"])


def _prune_snapshots():
    snaps = sorted(d for d in config.SAVE_SNAP_DIR.iterdir() if d.is_dir())
    for d in snaps[:-MAX_SNAPSHOTS]:
        shutil.rmtree(d, ignore_errors=True)


# ============================================================ vanilla files
def vanilla_manifest():
    return config.read_json(VANILLA_MANIFEST, {})


def has_vanilla(rel):
    return (config.VANILLA_DIR / rel).exists()


def vanilla_path(rel):
    return config.VANILLA_DIR / rel


def vanilla_sha1(rel):
    return vanilla_manifest().get(rel, {}).get("sha1")


def backup_vanilla(game_dir, rel, cache=None, force=False):
    """Copy a game file into the vanilla store (only if not already stored)."""
    src = Path(game_dir) / rel
    dest = config.VANILLA_DIR / rel
    man = vanilla_manifest()
    if dest.exists() and not force:
        return False
    if not src.exists():
        # The file doesn't exist in the vanilla game: remember that, so a
        man[rel] = {"absent": True}
        config.write_json(VANILLA_MANIFEST, man)
        return False
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    shutil.copy2(src, tmp)
    os.replace(tmp, dest)
    man[rel] = {"sha1": paths.sha1_file(dest, cache), "size": dest.stat().st_size,
                "time": time.time()}
    config.write_json(VANILLA_MANIFEST, man)
    return True


def backup_many(game_dir, rels, cache=None, log=None):
    """Back up many game files, writing the manifest once (fast for mods with
    hundreds of files). Returns how many were newly backed up."""
    man = vanilla_manifest()
    n = 0
    for rel in rels:
        if rel in man:
            continue
        src = Path(game_dir) / rel
        dest = config.VANILLA_DIR / rel
        if not src.exists():
            man[rel] = {"absent": True}
            continue
        if log and src.stat().st_size > 5_000_000:
            log(f"Backing up vanilla {rel}...")
        dest.parent.mkdir(parents=True, exist_ok=True)
        tmp = dest.with_suffix(dest.suffix + ".part")
        shutil.copy2(src, tmp)
        os.replace(tmp, dest)
        man[rel] = {"sha1": paths.sha1_file(dest, cache), "size": dest.stat().st_size,
                    "time": time.time()}
        n += 1
    config.write_json(VANILLA_MANIFEST, man)
    return n


def restore_vanilla_file(game_dir, rel, man=None):
    """Put one file back to vanilla (or delete it if the vanilla game didn't have it)."""
    entry = (man if man is not None else vanilla_manifest()).get(rel, {})
    target = Path(game_dir) / rel
    if entry.get("absent"):
        if target.exists():
            target.unlink()
        return
    src = config.VANILLA_DIR / rel
    if not src.exists():
        raise FileNotFoundError(f"No vanilla backup for {rel}")
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name(target.name + ".vessel-tmp")
    shutil.copy2(src, tmp)
    os.replace(tmp, target)


def restore_all_vanilla(game_dir):
    """Undo every mod: restore all backed-up files. Returns count."""
    man = vanilla_manifest()
    for rel in man:
        restore_vanilla_file(game_dir, rel, man)
    config.write_json(config.APPLIED_FILE, {})
    return len(man)


def refresh_vanilla(game_dir, rel, cache=None):
    """Game updated (Steam patch / verify): replace stored vanilla with the new file."""
    return backup_vanilla(game_dir, rel, cache, force=True)
