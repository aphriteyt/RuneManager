"""Finding Deltarune and poking at its files."""
import hashlib
import os
import re
import subprocess
import sys
from pathlib import Path

IS_WINDOWS = sys.platform.startswith("win")
STEAM_APP_ID = "1671210"  # deltarune on Steam

# Folder names Deltarune has shipped under (Steam full game
GAME_FOLDER_NAMES = ["DELTARUNE", "DELTARUNEdemo", "DELTARUNE demo", "SURVEY_PROGRAM"]
EXE_NAMES = ["DELTARUNE.exe", "deltarune.exe", "SURVEY_PROGRAM.exe"]

# Files/folders left behind by Steam emulators and cracks.
CRACK_MARKERS = [
    "steam_emu.ini", "SmartSteamEmu.ini", "SmartSteamEmu", "ColdClientLoader.ini",
    "cream_api.ini", "steam_settings", "OnlineFix.ini", "OnlineFix64.dll",
    "steam_api64_o.dll", "steam_api_o.dll", "CODEX.ini", "steam_interfaces.txt",
    "ALI213.ini", "3DMGAME.ini", "valve.ini", "SKIDROW.ini", "CPY.ini",
    "Goldberg", "goldberg_steam_emu", "steamclient_loader.exe",
]

CHAPTER_DIR_RE = re.compile(r"^chapter(\d+)_windows$", re.IGNORECASE)


# steam
def _steam_roots():
    """Every place a Steam install might live on this machine."""
    roots = []
    if IS_WINDOWS:
        try:
            import winreg
            for hive, key, val in [
                (winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam", "SteamPath"),
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath"),
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Valve\Steam", "InstallPath"),
            ]:
                try:
                    with winreg.OpenKey(hive, key) as k:
                        roots.append(Path(winreg.QueryValueEx(k, val)[0]))
                except OSError:
                    pass
        except ImportError:
            pass
        for env in ("ProgramFiles(x86)", "ProgramFiles"):
            if os.environ.get(env):
                roots.append(Path(os.environ[env]) / "Steam")
        for drive in "CDEFGH":
            roots.append(Path(f"{drive}:/Steam"))
            roots.append(Path(f"{drive}:/SteamLibrary"))
    else:
        home = Path.home()
        roots += [home / ".steam/steam", home / ".local/share/Steam",
                  home / "Library/Application Support/Steam"]
    seen, out = set(), []
    for r in roots:
        key = str(r).lower()
        if key not in seen and r.exists():
            seen.add(key)
            out.append(r)
    return out


def steam_libraries():
    """Steam root + every extra library listed in libraryfolders.vdf."""
    libs = []
    for root in _steam_roots():
        libs.append(root)
        vdf = root / "steamapps" / "libraryfolders.vdf"
        if vdf.exists():
            try:
                text = vdf.read_text(encoding="utf-8", errors="ignore")
                for m in re.finditer(r'"path"\s+"([^"]+)"', text):
                    libs.append(Path(m.group(1).replace("\\\\", "\\")))
            except OSError:
                pass
    seen, out = set(), []
    for lib in libs:
        key = str(lib).lower()
        if key not in seen:
            seen.add(key)
            out.append(lib)
    return out


def is_game_dir(path):
    p = Path(path)
    if not p.is_dir():
        return False
    if (p / "data.win").exists() or any((p / e).exists() for e in EXE_NAMES):
        return True
    return any(CHAPTER_DIR_RE.match(c.name) for c in p.iterdir() if c.is_dir())


def auto_detect_game():
    """Return the first Deltarune folder found in any Steam library, or None."""
    for lib in steam_libraries():
        common = lib / "steamapps" / "common"
        for name in GAME_FOLDER_NAMES:
            cand = common / name
            if is_game_dir(cand):
                return cand
    return None


def resolve_picked_path(path):
    """User may pick data.win, the exe, or a chapter folder. Turn it into the game root."""
    p = Path(path)
    if p.is_file():
        p = p.parent
    if CHAPTER_DIR_RE.match(p.name) and is_game_dir(p.parent):
        return p.parent
    return p


def find_exe(game_dir):
    for e in EXE_NAMES:
        if (Path(game_dir) / e).exists():
            return Path(game_dir) / e
    return None


def find_data_wins(game_dir):
    """All data.win files, as forward-slash paths relative to the game folder.
    Root data.win = chapter select; chapterN_windows/data.win = each chapter."""
    game_dir = Path(game_dir)
    found = []
    if (game_dir / "data.win").exists():
        found.append("data.win")
    try:
        chapters = sorted(
            (c for c in game_dir.iterdir() if c.is_dir() and CHAPTER_DIR_RE.match(c.name)),
            key=lambda c: int(CHAPTER_DIR_RE.match(c.name).group(1)))
    except OSError:
        chapters = []
    for c in chapters:
        if (c / "data.win").exists():
            found.append(f"{c.name}/data.win")
    return found


def save_dir():
    """Where Deltarune keeps filech1_0, filech2_0, ... and dr.ini."""
    if IS_WINDOWS:
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData/Local")
        return Path(base) / "DELTARUNE"
    if sys.platform == "darwin":
        return Path.home() / "Library/Application Support/com.tobyfox.deltarune"
    return Path.home() / ".config" / "DELTARUNE"


# legitimacy check
def legitimacy_check(game_dir):
    """
    Returns (ok, notes). ok=False means crack/emulator files were found and the
    manager should lock. A copy outside Steam (e.g. the free itch.io demo) is
    allowed but noted.
    """
    game_dir = Path(game_dir)
    notes, bad = [], []
    for root, dirs, files in os.walk(game_dir):
        depth = Path(root).relative_to(game_dir).parts
        if len(depth) > 1:          # only the root and one level down
            dirs[:] = []
            continue
        names = {n.lower() for n in files + dirs}
        for marker in CRACK_MARKERS:
            if marker.lower() in names:
                bad.append(str(Path(root, marker).relative_to(game_dir)))
    if bad:
        return False, ["Emulator/crack files found: " + ", ".join(sorted(set(bad)))]

    parts = [x.lower() for x in game_dir.resolve().parts]
    if "steamapps" in parts and "common" in parts:
        steamapps = Path(*game_dir.resolve().parts[:parts.index("steamapps") + 1])
        manifest = steamapps / f"appmanifest_{STEAM_APP_ID}.acf"
        if manifest.exists():
            notes.append("Steam copy verified (app manifest found).")
        else:
            notes.append("In a Steam folder, but no Deltarune app manifest. "
                         "If this is a demo build that's fine.")
    else:
        notes.append("Non-Steam copy (free demo / itch build). Allowed.")
    return True, notes


# hashing
def sha1_file(path, cache=None):
    """SHA-1 of a file. Optional cache dict keyed by path -> [size, mtime, sha1]."""
    path = Path(path)
    st = path.stat()
    key = str(path)
    if cache is not None:
        hit = cache.get(key)
        if hit and hit[0] == st.st_size and abs(hit[1] - st.st_mtime) < 0.001:
            return hit[2]
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    digest = h.hexdigest()
    if cache is not None:
        cache[key] = [st.st_size, st.st_mtime, digest]
    return digest


HASH_BY_LENGTH = {32: "md5", 40: "sha1", 64: "sha256"}


def hash_file(path, algo, cache=None):
    """md5 / sha1 / sha256 of a file, cached by size + modified time."""
    path = Path(path)
    st = path.stat()
    key = f"{algo}:{path}"
    if cache is not None:
        hit = cache.get(key)
        if hit and hit[0] == st.st_size and abs(hit[1] - st.st_mtime) < 0.001:
            return hit[2]
    h = hashlib.new(algo)
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(chunk)
    digest = h.hexdigest()
    if cache is not None:
        cache[key] = [st.st_size, st.st_mtime, digest]
    return digest


def is_cached(path, algo, cache):
    path = Path(path)
    st = path.stat()
    hit = cache.get(f"{algo}:{path}")
    return bool(hit and hit[0] == st.st_size and abs(hit[1] - st.st_mtime) < 0.001)


def is_game_running():
    """True if DELTARUNE.exe is running (Windows only; elsewhere returns False)."""
    if not IS_WINDOWS:
        return False
    try:
        out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq DELTARUNE.exe"],
                             capture_output=True, text=True, timeout=5,
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return "deltarune.exe" in out.stdout.lower()
    except (OSError, subprocess.SubprocessError):
        return False


def launch_game(game_dir):
    """Launch through Steam if it's a Steam copy (keeps the real launcher happy), else the exe."""
    game_dir = Path(game_dir)
    if "steamapps" in [x.lower() for x in game_dir.parts]:
        url = f"steam://rungameid/{STEAM_APP_ID}"
        if IS_WINDOWS:
            os.startfile(url)  # noqa
            return
    exe = find_exe(game_dir)
    if exe is None:
        raise FileNotFoundError("Couldn't find DELTARUNE.exe in the game folder.")
    subprocess.Popen([str(exe)], cwd=str(game_dir))


def open_folder(path):
    path = str(path)
    if IS_WINDOWS:
        os.startfile(path)  # noqa
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])
