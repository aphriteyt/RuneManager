"""GitHub release downloads."""
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path

from . import config

API = "https://api.github.com"      # overridden in tests
UA = {"User-Agent": "RuneManager/1.0"}
_cache = {}                         # url -> (time, data), so repeated clicks don't
CACHE_SECONDS = 900                 # burn GitHub's 60-requests-per-hour limit
GOOD_ASSET_EXTS = (".zip", ".7z", ".xdelta", ".vcdiff", ".bps", ".win", ".dll")
BAD_ASSET_RE = re.compile(
    r"mac|osx|darwin|switch|android|\.apk|(?:^|[^a-z])ios|ps4|ps5|xbox|demo|source|"
    r"installer|script|csx|bsdiff|debug|symbols", re.I)
PC_HINT_RE = re.compile(r"win|pc|steam|full", re.I)

GH_REPO_RE = re.compile(
    r"^(?:github:|https?://github\.com/)([\w.\-]+)/([\w.\-]+?)(?:\.git)?/?(?:releases(?:/latest)?/?)?$")
GH_BLOB_RE = re.compile(r"^https?://github\.com/([^/]+)/([^/]+)/blob/(.+)$")

# Repos that redistribute the game itself or aren't game mods - never offered
SEARCH_BLOCK_RE = re.compile(
    r"apk|android|full[\s_-]?game|free|download|crack|vita|3ds|switch|port|decomp|"
    r"terraria|minecraft|fnf|friday|engine|fangame|recreation|remake|godot|unity|roblox", re.I)


class DownloadError(Exception):
    pass


class Cancelled(Exception):
    pass


def _get_json(url, use_cache=True):
    hit = _cache.get(url)
    if use_cache and hit and time.time() - hit[0] < CACHE_SECONDS:
        return hit[1]
    req = urllib.request.Request(url, headers={**UA, "Accept": "application/vnd.github+json"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            data = json.loads(r.read().decode("utf-8"))
            _cache[url] = (time.time(), data)
            return data
    except urllib.error.HTTPError as exc:
        if exc.code in (403, 429):
            raise DownloadError("GitHub is rate-limiting this PC (it allows about 60 "
                                "checks an hour without an account). Wait a while, then "
                                "try again - downloads themselves still work.")
        if exc.code == 404:
            raise DownloadError("That GitHub repo or release doesn't exist (or has no releases).")
        raise DownloadError(f"GitHub error {exc.code}.")
    except DownloadError:
        raise
    except Exception as exc:
        raise DownloadError(f"Couldn't reach GitHub: {exc}")


def pick_asset(assets, pattern=""):
    """Choose the release file to download. Returns the asset dict or None."""
    named = [a for a in assets if a["name"].lower().endswith(GOOD_ASSET_EXTS)]
    if pattern:
        rx = re.compile(pattern, re.I)
        hits = [a for a in named if rx.search(a["name"])]
        return hits[0] if hits else None
    usable = [a for a in named if not BAD_ASSET_RE.search(a["name"])
              and not ("linux" in a["name"].lower() and "win" not in a["name"].lower())]
    if not usable:
        return None
    usable.sort(key=lambda a: (not a["name"].lower().endswith((".zip", ".7z")),
                               not PC_HINT_RE.search(a["name"])))
    return usable[0]


def _release_for(owner, repo, pattern="", prerelease=False):
    """(release, asset) - newest release that has a usable file."""
    if not pattern and not prerelease:
        try:
            rel = _get_json(f"{API}/repos/{owner}/{repo}/releases/latest")
            asset = pick_asset(rel.get("assets", []))
            if asset:
                return rel, asset
        except DownloadError:
            pass                      # no "latest" - look through older releases below
    rels = _get_json(f"{API}/repos/{owner}/{repo}/releases?per_page=20")
    if not rels:
        raise DownloadError(f"{owner}/{repo} has no releases to download "
                            "(its code is there, but no packaged mod).")
    for rel in rels:
        if rel.get("draft") or (rel.get("prerelease") and not prerelease):
            continue
        asset = pick_asset(rel.get("assets", []), pattern)
        if asset:
            return rel, asset
    raise DownloadError(f"No installable download found in {owner}/{repo}'s releases.")


def resolve(url, pattern="", prerelease=False):
    """Turn a catalog link into (direct_download_url, version_tag, filename)."""
    url = url.strip()
    if not url:
        raise DownloadError("This download button has no link yet - press EDIT to add one.")
    m = GH_REPO_RE.match(url)
    if m:
        owner, repo = m.groups()
        rel, asset = _release_for(owner, repo, pattern, prerelease)
        return asset["browser_download_url"], rel.get("tag_name", ""), asset["name"]
    m = GH_BLOB_RE.match(url)
    if m:
        owner, repo, rest = m.groups()
        url = f"https://raw.githubusercontent.com/{owner}/{repo}/{rest}"
    name = Path(urllib.parse.urlparse(url).path).name or "mod.zip"
    return url, "", urllib.parse.unquote(name)


def latest_version(url, pattern="", prerelease=False):
    """Version tag of the newest usable GitHub release, or '' for non-GitHub links."""
    if GH_REPO_RE.match(url.strip()):
        try:
            return resolve(url, pattern, prerelease)[1]
        except DownloadError:
            return ""
    return ""


def download(url, progress=None, cancel_event=None, pattern="", prerelease=False):
    """Download a catalog link."""
    direct, version, name = resolve(url, pattern, prerelease)
    out_dir = config.TEMP_DIR / ("dl_" + uuid.uuid4().hex[:8])
    out_dir.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(direct, headers=UA)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            cd = r.headers.get("Content-Disposition", "")
            m = re.search(r'filename="?([^";]+)"?', cd)
            if m:
                name = m.group(1)
            name = re.sub(r'[\\/:*?"<>|]', "_", name) or "mod.zip"
            total = int(r.headers.get("Content-Length") or 0)
            done = 0
            out = out_dir / name
            with open(out, "wb") as f:
                while True:
                    if cancel_event is not None and cancel_event.is_set():
                        raise Cancelled()
                    chunk = r.read(256 * 1024)
                    if not chunk:
                        break
                    f.write(chunk)
                    done += len(chunk)
                    if progress:
                        progress(done, total)
    except (Cancelled, DownloadError):
        raise
    except Exception as exc:
        raise DownloadError(f"Download failed: {exc}")
    return out, version


def search_github(query="deltarune mod"):
    """Search GitHub for Deltarune mod repos."""
    q = urllib.parse.quote(f"{query} in:name,description,topics fork:false")
    data = _get_json(f"{API}/search/repositories?q={q}&sort=updated&per_page=50")
    out = []
    for r in data.get("items", []):
        text = f"{r['full_name']} {r.get('description') or ''}"
        if "deltarune" not in text.lower() or SEARCH_BLOCK_RE.search(text):
            continue
        out.append({"repo": r["full_name"], "name": r["name"].replace("-", " ").replace("_", " "),
                    "author": r["owner"]["login"], "description": (r.get("description") or "")[:200],
                    "stars": r.get("stargazers_count", 0), "updated": r.get("pushed_at", "")[:10],
                    "url": r["html_url"]})
    return out


def check_repo(repo):
    """Does this repo have an installable release? Returns (ok, message)."""
    owner, name = repo.split("/", 1)
    try:
        rel, asset = _release_for(owner, name)
        return True, f"{rel.get('tag_name', '')}: {asset['name']}"
    except DownloadError as exc:
        return False, str(exc)
