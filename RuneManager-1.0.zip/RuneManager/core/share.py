"""Share codes."""
import base64
import json
import zlib

PREFIX = "GONER-"


def encode(mods_in_order):
    """mods_in_order: list of Mod objects that are enabled, in load order."""
    payload = {"v": 1, "m": [
        {"i": m.id, "n": m.name, "v": m.version, "u": m.source_url} for m in mods_in_order]}
    raw = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    packed = zlib.compress(raw, 9)
    return PREFIX + base64.urlsafe_b64encode(packed).decode("ascii").rstrip("=")


def decode(code):
    """Returns list of dicts: {id, name, version, url}. Raises ValueError on a bad code."""
    code = "".join(code.split())
    if not code.upper().startswith(PREFIX):
        raise ValueError("That isn't a share code (it should start with GONER-).")
    body = code[len(PREFIX):]
    body += "=" * (-len(body) % 4)
    try:
        data = json.loads(zlib.decompress(base64.urlsafe_b64decode(body)).decode("utf-8"))
    except Exception as exc:
        raise ValueError("The share code is damaged or incomplete.") from exc
    if data.get("v") != 1 or not isinstance(data.get("m"), list):
        raise ValueError("Unknown share code version.")
    return [{"id": str(m.get("i", "")), "name": str(m.get("n", "")),
             "version": str(m.get("v", "")), "url": str(m.get("u", ""))}
            for m in data["m"]]
