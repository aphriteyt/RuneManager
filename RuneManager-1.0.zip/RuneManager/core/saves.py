"""Deltarune save files - plain text, one value per line."""
import os
import re
from pathlib import Path

from . import backup, config, paths

SAVE_RE = re.compile(r"^filech(\d+)_(\d+)$", re.IGNORECASE)


class SaveFile:
    def __init__(self, path):
        self.path = Path(path)
        raw = self.path.read_bytes()
        self.newline = "\r\n" if b"\r\n" in raw else "\n"
        text = raw.decode("utf-8", errors="surrogateescape")
        self.trailing = text.endswith(("\n", "\r\n"))
        self.lines = text.splitlines()
        self.original = list(self.lines)

    @property
    def chapter_key(self):
        m = SAVE_RE.match(self.path.name)
        return f"ch{m.group(1)}" if m else self.path.name

    @property
    def dirty(self):
        return self.lines != self.original

    def set(self, index, value):
        value = str(value)
        if "\n" in value or "\r" in value:
            raise ValueError("A save value can't contain line breaks.")
        if not 0 <= index < len(self.lines):
            raise IndexError(f"Line {index} doesn't exist in this save.")
        self.lines[index] = value

    def find_value(self, value):
        """Indexes of lines whose value equals `value` (numbers compared numerically)."""
        value = str(value).strip()
        hits = []
        for i, line in enumerate(self.lines):
            s = line.strip()
            if s == value:
                hits.append(i)
            else:
                try:
                    if float(s) == float(value):
                        hits.append(i)
                except ValueError:
                    pass
        return hits

    def write(self):
        """Snapshot every save, then write this file atomically."""
        if paths.is_game_running():
            raise RuntimeError("Close DELTARUNE first - it overwrites saves when you save in-game.")
        backup.snapshot_saves("before-edit")
        text = self.newline.join(self.lines) + (self.newline if self.trailing else "")
        tmp = self.path.with_name(self.path.name + ".vessel-tmp")
        tmp.write_bytes(text.encode("utf-8", errors="surrogateescape"))
        os.replace(tmp, self.path)
        self.original = list(self.lines)


def list_save_files():
    """Chapter save slots in the save folder, sorted ch1 slot0, ch1 slot1, ..."""
    d = paths.save_dir()
    if not d.exists():
        return []
    files = [p for p in d.iterdir() if p.is_file() and SAVE_RE.match(p.name)]
    return sorted(files, key=lambda p: tuple(int(x) for x in SAVE_RE.match(p.name).groups()))


def diff_lines(old, new):
    """[(index, old_value, new_value)] for every line that differs."""
    out = []
    for i in range(max(len(old), len(new))):
        a = old[i] if i < len(old) else "<none>"
        b = new[i] if i < len(new) else "<none>"
        if a != b:
            out.append((i, a, b))
    return out


# labels
def load_labels():
    return config.read_json(config.LABELS_FILE, {})


def set_label(chapter_key, index, label):
    labels = load_labels()
    ch = labels.setdefault(chapter_key, {})
    if label.strip():
        ch[str(index)] = label.strip()
    else:
        ch.pop(str(index), None)
    config.write_json(config.LABELS_FILE, labels)


# secret presets
def load_presets():
    return config.read_json(config.PRESETS_FILE, [])


def save_presets(presets):
    config.write_json(config.PRESETS_FILE, presets)


def apply_preset(preset, save):
    """Write a preset's line edits into a SaveFile (and to disk)."""
    if preset.get("chapter") and preset["chapter"] != save.chapter_key:
        raise ValueError(f"This preset is for {preset['chapter']}, "
                         f"but the selected save is {save.chapter_key}.")
    for e in preset.get("edits", []):
        save.set(int(e["line"]), e["value"])
    save.write()
    return len(preset.get("edits", []))
