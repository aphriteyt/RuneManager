"""Mod install/apply. Each mod lives in mods/<id>/ with a mod.json."""
import os
import re
import shutil
import subprocess
import sys
import uuid
import zipfile
from pathlib import Path

from . import backup, bps, config, paths

PATCH_EXTS = {".xdelta", ".vcdiff", ".delta"}
BPS_EXTS = {".bps"}
OTHER_PLATFORM_RE = re.compile(r"(?:^|[^a-z])(mac|macos|osx|switch|nx|linux|android|ios|ps4|ps5|xbox)(?:[^a-z]|$)")
SKIP_EXTS = {".txt", ".md", ".pdf", ".url", ".html", ".htm", ".exe", ".bat",
             ".cmd", ".ps1", ".lnk", ".png", ".jpg", ".jpeg", ".gif", ".webp"}
UNKNOWN = "?"
# Bumped whenever the auto-importer learns something new about where a mod's
OPS_SCHEMA = 2


class ModError(Exception):
    pass


# model
class Mod:
    def __init__(self, folder):
        self.dir = Path(folder)
        self.manifest = config.read_json(self.dir / "mod.json", {})
        m = self.manifest
        self.id = m.get("id") or self.dir.name
        self.name = m.get("name") or self.id
        self.version = str(m.get("version", "1.0"))
        self.author = m.get("author", "unknown")
        self.description = m.get("description", "")
        self.source_url = m.get("source_url", "")
        self.operations = m.get("operations", [])

    @property
    def requires(self):
        return self.manifest.get("requires") or []

    @property
    def targets(self):
        return [op.get("target", UNKNOWN) for op in self.operations]

    @staticmethod
    def source_of(op):
        return op.get("source") or op.get("target", UNKNOWN)

    @property
    def sources(self):
        return [self.source_of(op) for op in self.operations]

    def summary(self):
        """Short human description of what this mod changes."""
        wins = sorted({t for t in self.targets if t.endswith("data.win")})
        other = [t for t in self.targets if not t.endswith("data.win")]
        bits = []
        if wins:
            names = ["chapter select" if w == "data.win" else
                     w.split("_")[0].replace("chapter", "ch") for w in wins]
            bits.append("game files: " + ", ".join(names))
        if other:
            folders = sorted({t.split("/")[0] for t in other})
            bits.append(f"{len(other)} file(s) in " + ", ".join(folders[:3])
                        + ("..." if len(folders) > 3 else ""))
        return "  |  ".join(bits) or "nothing"

    def needs_target(self):
        return any(t in ("", UNKNOWN, None) for t in self.targets)

    def save(self):
        self.manifest["operations"] = self.operations
        config.write_json(self.dir / "mod.json", self.manifest)


def list_mods():
    """All installed mods, keyed by id."""
    out = {}
    if not config.MODS_DIR.exists():
        return out
    for d in sorted(config.MODS_DIR.iterdir()):
        if d.is_dir() and (d / "mod.json").exists():
            mod = Mod(d)
            if upgrade_manifest(mod):
                mod = Mod(d)
            out[mod.id] = mod
    return out


def slugify(text):
    s = re.sub(r"[^a-zA-Z0-9]+", "-", text).strip("-").lower()
    return s[:48] or "mod"


# importing
def guess_target(filename, targets):
    """Guess which data.win a patch is for from its file name.
    'chapter_select' / 'main' / 'demo' / 'chapter_0' -> data.win;
    'ch5_latest-chapter2' -> chapter2 (the LAST chapter number wins, so a build tag
    like 'ch5_latest' isn't mistaken); 'patch_cap3' / 'deltaUA-ch3' -> chapter3."""
    name = filename.lower()
    root_ok = not targets or "data.win" in targets
    if re.search(r"chapter[ _\-]?select|chapterselect|demo|launcher|(?:^|[^a-z])main(?:[^a-z]|$)", name):
        return "data.win" if root_ok else UNKNOWN
    nums = (re.findall(r"chapter[ _\-]?(\d+)", name)
            or re.findall(r"(?:^|[^a-z])(?:ch|cap|chap)[ _\-]?(\d+)", name))
    if nums:
        n = int(nums[-1])
        if n == 0:
            return "data.win" if root_ok else UNKNOWN
        want = f"chapter{n}_windows/data.win"
        if not targets or want in targets:
            return want
    chapter_targets = [t for t in targets if t != "data.win"]
    if len(chapter_targets) == 1:
        return chapter_targets[0]
    if len(targets) == 1:
        return targets[0]
    return UNKNOWN


# archives
def _safe_members(names, dest):
    dest = Path(dest).resolve()
    for n in names:
        out = (dest / n).resolve()
        if dest not in out.parents and out != dest:
            raise ModError(f"Unsafe path inside archive: {n}")


def extract_archive(path, dest):
    """Unpack .zip or .7z into dest (refusing paths that escape it)."""
    path = Path(path)
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as z:
            _safe_members(z.namelist(), dest)
            z.extractall(dest)
        return True
    with open(path, "rb") as f:
        is_7z = f.read(6) == b"7z\xbc\xaf\x27\x1c"
    if is_7z:
        try:
            import py7zr
        except ImportError:
            if _extract_with_tool(path, dest):
                return True
            raise ModError(
                "This mod comes as a .7z archive, which Python can't open on its own.\n\n"
                "Easiest fix: install 7-Zip (7-zip.org) and try again - RuneManager "
                "will use it automatically.\n\n"
                "Or: right-click the .7z, Extract Here, zip the extracted folder, and "
                "use IMPORT MOD FILE on that zip.")
        with py7zr.SevenZipFile(path) as z:
            _safe_members(z.getnames(), dest)
            z.extractall(dest)
        return True
    with open(path, "rb") as f:
        head = f.read(8)
    if head[:4] == b"Rar!":
        return _extract_rar(path, dest)
    return False


def _extract_rar(path, dest):
    """.rar needs an outside unpacker."""
    try:
        import rarfile
        with rarfile.RarFile(path) as r:
            _safe_members(r.namelist(), dest)
            r.extractall(dest)
        return True
    except ImportError:
        pass
    except Exception as exc:
        raise ModError(f"Couldn't open that .rar: {exc}")
    if _extract_with_tool(path, dest):
        return True
    raise ModError(
        "This mod is a .rar archive, which Python can't open on its own.\n\n"
        "Easiest fix: install 7-Zip (7-zip.org) and try again - RuneManager will "
        "use it automatically.\n\n"
        "Or: right-click the .rar, Extract Here, zip the extracted folder, and "
        "use IMPORT MOD FILE on that zip.")


def _extract_with_tool(path, dest):
    """Unpack with an installed 7-Zip / WinRAR. True if one of them managed it."""
    for exe in _unpacker_exes():
        try:
            res = subprocess.run([str(exe), "x", "-y", f"-o{dest}", str(path)],
                                 capture_output=True, text=True, timeout=900,
                                 creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
                                 if sys.platform.startswith("win") else 0)
        except (OSError, subprocess.SubprocessError):
            continue
        if res.returncode == 0 and any(Path(dest).iterdir()):
            _safe_members([p.relative_to(dest).as_posix()
                           for p in Path(dest).rglob("*")], dest)
            return True
    return False


def _unpacker_exes():
    """7-Zip / WinRAR command-line tools, if they're installed."""
    found = []
    for name in ("7z", "7za", "7zz"):
        w = shutil.which(name)
        if w:
            found.append(Path(w))
    if sys.platform.startswith("win"):
        for base in (os.environ.get("ProgramFiles", r"C:\Program Files"),
                     os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")):
            for rel in (r"7-Zip\7z.exe", r"WinRAR\UnRAR.exe", r"WinRAR\WinRAR.exe"):
                p = Path(base) / rel
                if p.exists():
                    found.append(p)
    return found


GAME_ROOT_NAMES = {"data.win", "lang", "mus", "vid", "sfx", "options.ini"}


def _game_path(parts):
    """Where in the game folder this archive path belongs, or None if nowhere.

    toDELTARUNEfolder/chapter1_windows/data.win -> chapter1_windows/data.win
    """
    low = [p.lower() for p in parts]
    for i, p in enumerate(low):
        if p in GAME_ROOT_NAMES or paths.CHAPTER_DIR_RE.match(p):
            return "/".join(parts[i:])
    return None


def _find_root(folder):
    """Step into a wrapping folder, but never into mus/ or chapterN_windows/."""
    folder = Path(folder)
    while True:
        if (folder / "mod.json").exists():
            return folder
        kids = [k for k in folder.iterdir() if not k.name.startswith(("__MACOSX", "."))]
        if (len(kids) == 1 and kids[0].is_dir() and _game_path([kids[0].name]) is None):
            folder = kids[0]
            continue
        return folder


def _read_meta(root):
    """Deltamod/GM3P metadata, including the checksums the patches expect."""
    meta = {"needed": {}}
    info = config.read_json(root / "_deltamodInfo.json", None) or config.read_json(root / "meta.json", None)
    if isinstance(info, dict):
        md = info.get("metadata", info)
        meta.update({k: md.get(k) for k in ("name", "version", "description") if md.get(k)})
        if md.get("author"):
            a = md["author"]
            meta["author"] = ", ".join(a) if isinstance(a, list) else str(a)
        for nf in info.get("neededFiles", []) or []:
            if isinstance(nf, dict) and nf.get("file") and nf.get("checksum"):
                meta["needed"][nf["file"].lstrip("./").replace("\\", "/")] = nf["checksum"].lower()
    toml = root / "meta.toml"
    if toml.exists():
        text = toml.read_text(encoding="utf-8", errors="ignore")
        for key in ("name", "version", "description"):
            m = re.search(rf'^\s*{key}\s*=\s*"([^"]*)"', text, re.M)
            if m and not meta.get(key):
                meta[key] = m.group(1)
        m = re.search(r'^\s*author\s*=\s*\[([^\]]*)\]', text, re.M)
        if m and not meta.get("author"):
            meta["author"] = ", ".join(re.findall(r'"([^"]+)"', m.group(1)))
        for f, c in re.findall(r'file\s*=\s*"([^"]+)"\s*\n\s*checksum\s*=\s*"([0-9a-fA-F]+)"', text):
            meta["needed"].setdefault(f.lstrip("./").replace("\\", "/"), c.lower())
    return meta


def _modding_xml_ops(root):
    """Read modding.xml (the Deltamod/G3M modpack format).

    <patch type="xdelta"   patch="./x.xdelta" to="./chapter1_windows/data.win"/>
    <patch type="override" patch="./y.win"    to="./chapter4_windows/data.win"/>

    types: xdelta/vcdiff patch the target; override and copy replace it (or add
    it if it isn't there); g3mpatch and csx need tools we don't ship.
    """
    xml = root / "modding.xml"
    if not xml.exists():
        return None
    text = xml.read_text(encoding="utf-8", errors="ignore")
    ops, needs_tool = [], set()
    for tag in re.findall(r"<patch\b[^>]*>", text, re.I):
        attrs = {k.lower(): v for k, v in re.findall(r'(\w+)\s*=\s*"([^"]*)"', tag)}
        kind = attrs.get("type", "").lower()
        src = attrs.get("patch", "").replace("\\", "/").lstrip("./")
        dst = attrs.get("to", "").replace("\\", "/").lstrip("./")
        if not src or not dst or ".." in Path(dst).parts or not (root / src).is_file():
            continue            # the spec says to ignore a patch with bad fields
        ext = Path(src).suffix.lower()
        if ext == ".csx" or kind == "csx":
            needs_tool.add("UndertaleModTool (.csx scripts)")
            continue
        if ext == ".g3mpatch" or kind == "g3mpatch":
            needs_tool.add("G3M (.g3mpatch files)")
            continue
        if kind in ("xdelta", "vcdiff"):
            # this type also accepts a whole .win, which means "use this file"
            op = "replace" if ext == ".win" else "xdelta"
            ops.append({"type": op, "file": "payload/" + src, "target": dst})
        elif kind == "bps" or ext == ".bps":
            ops.append({"type": "bps", "file": "payload/" + src,
                        "candidates": ["payload/" + src], "target": dst})
        elif kind in ("override", "copy"):
            op = "replace" if dst.lower().endswith(".win") else "copy"
            ops.append({"type": op, "file": "payload/" + src, "target": dst})
        else:
            needs_tool.add(f"an unknown patch type ('{kind}')")
    if needs_tool and not ops:
        raise ModError("This mod needs " + " and ".join(sorted(needs_tool))
                       + ", which RuneManager can't run. Install it with that tool "
                         "instead.")
    if needs_tool:
        raise ModError("Part of this mod needs " + " and ".join(sorted(needs_tool))
                       + ". Installing only the rest would leave the game broken, so "
                         "RuneManager stopped. Use that tool for this one.")
    return ops


OUTPUT_SUFFIX_RE = re.compile(r"\bdata_([a-z0-9]{3,20})\.win\b", re.I)


def detect_output_suffix(root):
    """Some mods (the FLB practice mod, for one) patch each chapter into a NEW file
    next to the original - chapter1_windows/data_practice.win - because their patched
    chapter-select launcher starts chapters with '-game data_practice.win'. The mod's
    own readme/installer says which name it uses; find it so we write the same one."""
    names = {}
    for f in root.rglob("*"):
        if f.is_file() and f.suffix.lower() in (".txt", ".md", ".bat", ".cmd", ".ps1", ".sh"):
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for m in OUTPUT_SUFFIX_RE.findall(text):
                names[m.lower()] = names.get(m.lower(), 0) + 1
    if not names:
        return ""
    return max(names, key=names.get)


def _auto_operations(root, targets):
    """Build operations for a mod that didn't ship a mod.json."""
    ops, skipped = [], []
    bps_groups = {}
    suffix = detect_output_suffix(root)
    xml_ops = _modding_xml_ops(root)
    if xml_ops:
        ops = xml_ops
        suffix = ""              # modding.xml already states the exact destinations
    for f in sorted(p for p in root.rglob("*") if p.is_file()):
        rel = f.relative_to(root).as_posix()
        ext = f.suffix.lower()
        if xml_ops and ext in PATCH_EXTS | BPS_EXTS:
            continue                       # modding.xml already said where these go
        if f.name in ("modding.xml", "meta.toml", "meta.json", "_deltamodInfo.json", "mod_config.json"):
            continue
        if ext in PATCH_EXTS | BPS_EXTS and OTHER_PLATFORM_RE.search(f.stem.lower()):
            skipped.append(rel)            # Mac / Switch / ... patch, not for PC
            continue
        if ext in BPS_EXTS:
            # A mod may ship one .bps per game version for the same file; keep them
            # all, and pick the one whose checksum matches the player's game later.
            bps_groups.setdefault(guess_target(f.name, targets), []).append("payload/" + rel)
            continue
        if ext in PATCH_EXTS:
            ops.append({"type": "xdelta", "file": "payload/" + rel,
                        "target": guess_target(f.name, targets)})
            continue
        if ext in (".exe", ".bat", ".cmd", ".ps1", ".vbs", ".sh", ".csx", ".apk", ".jar",
                   ".dylib", ".so"):
            skipped.append(rel)            # the mod's own patcher tools - not game files
            continue
        game = _game_path(f.relative_to(root).parts)
        if game is None and ext == ".dll" and len(f.relative_to(root).parts) == 1:
            game = f.name                  # loose DLL next to the game exe
        if game is None and ext == ".win" and f.name.lower().startswith("data"):
            game = guess_target(f.name, targets)
        if game is None:
            skipped.append(rel)            # readme, icon, tools folder...
            continue
        kind = "replace" if game.lower().endswith("data.win") else "copy"
        ops.append({"type": kind, "file": "payload/" + rel, "target": game})
    for target, files in sorted(bps_groups.items()):
        ops.insert(0, {"type": "bps", "file": files[0], "candidates": files, "target": target})
    if suffix:
        for op in ops:
            t = op.get("target", "")
            if op["type"] in ("bps", "xdelta") and t.endswith("/data.win"):
                op["source"] = t
                op["target"] = t[:-len("data.win")] + f"data_{suffix}.win"
    # One mod shouldn't write the same game file twice (e.g.
    seen, unique = set(), []
    for op in ops:
        if op["target"] in seen and op["target"] != UNKNOWN:
            skipped.append(op["file"].replace("payload/", "", 1))
            continue
        seen.add(op["target"])
        unique.append(op)
    return unique, skipped


def pick_bps(mod, op, source_file, cache=None):
    """The candidate .bps whose source checksum matches this exact game file, or None."""
    crc = bps.crc32_file(source_file, cache)
    for rel in op.get("candidates") or [op["file"]]:
        try:
            if bps.read_footer(mod.dir / rel)[0] == crc:
                return mod.dir / rel
        except (OSError, bps.BPSError):
            continue
    return None


def auto_ops(root, targets):
    """Operations for a mod with no mod.json, with the version checksums it ships."""
    ops, skipped = _auto_operations(root, targets)
    meta = _read_meta(root)
    for op in ops:
        want = meta["needed"].get(op["target"]) or meta["needed"].get(Mod.source_of(op))
        if want and op["type"] in ("xdelta", "bps"):
            op["expect_hash"] = want
    return ops, skipped, meta


def upgrade_manifest(mod):
    """Redo an auto-imported mod's file mapping when we've since learned better.

    Mods that shipped their own mod.json are left exactly as the author wrote them.
    """
    m = mod.manifest
    if not (m.get("auto") or m.get("description") == "Auto-imported."):
        return False
    if m.get("ops_schema", 0) >= OPS_SCHEMA:
        return False
    payload = mod.dir / "payload"
    if not payload.is_dir():
        return False
    try:
        ops, _, _ = auto_ops(payload, [])
    except ModError:
        return False
    if not ops:
        return False
    m["ops_schema"] = OPS_SCHEMA
    mod.operations = ops
    mod.save()
    return True


def import_mod(source, game_dir=None, source_url="", source_version="",
               name_hint="", cache=None, mod_id=None, description="", requires=()):
    """Install a .zip / .7z / .xdelta / .bps / .win / .dll into mods/."""
    source = Path(source)
    if not source.exists():
        raise ModError(f"File not found: {source}")
    targets = paths.find_data_wins(game_dir) if game_dir else []
    work = config.TEMP_DIR / ("import_" + uuid.uuid4().hex[:8])
    work.mkdir(parents=True)
    notes = []
    try:
        if not extract_archive(source, work):
            shutil.copy2(source, work / source.name)
        root = _find_root(work)

        if (root / "mod.json").exists():
            manifest = config.read_json(root / "mod.json", None)
            if not isinstance(manifest, dict):
                raise ModError("The mod's mod.json is not valid JSON.")
            for op in manifest.get("operations", []):
                f = (root / op.get("file", "")).resolve()
                if root.resolve() not in f.parents or not f.exists():
                    raise ModError(f"mod.json points at a missing/unsafe file: {op.get('file')}")
                if ".." in Path(op.get("target", "")).parts:
                    raise ModError(f"mod.json has an unsafe target: {op.get('target')}")
            payload_from, payload_to = root, ""
        else:
            ops, skipped, meta = auto_ops(root, targets)
            if not ops:
                raise ModError("Nothing installable found in this download (no patches, "
                               "data.win or game files). It may need its own installer.")
            base = name_hint or meta.get("name") or source.stem
            manifest = {"id": slugify(mod_id or base), "name": base,
                        "version": source_version or meta.get("version") or "1.0",
                        "author": meta.get("author") or "unknown",
                        "description": description or meta.get("description") or "Auto-imported.",
                        "auto": True, "ops_schema": OPS_SCHEMA, "operations": ops}
            if skipped:
                notes.append(f"Skipped {len(skipped)} file(s) that aren't game files "
                             f"(readmes, tools, other platforms): " + ", ".join(skipped[:5])
                             + (" ..." if len(skipped) > 5 else ""))
            payload_from, payload_to = root, "payload"

        manifest.setdefault("id", slugify(manifest.get("name", source.stem)))
        manifest["id"] = slugify(manifest["id"])
        if source_url:
            manifest["source_url"] = source_url
        if source_version:
            manifest["source_version"] = source_version
        if requires:
            manifest["requires"] = [dict(q) for q in requires]

        # Remember which vanilla files this mod was imported against, so we can
        imported_against = {}
        if game_dir:
            for op in manifest["operations"]:
                t = op.get("target")
                if t and t != UNKNOWN and t.endswith("data.win"):
                    sha = backup.vanilla_sha1(t)
                    if not sha and (Path(game_dir) / t).exists():
                        sha = paths.sha1_file(Path(game_dir) / t, cache)
                    if sha:
                        imported_against[t] = sha
        manifest["imported_against"] = imported_against

        dest = config.MODS_DIR / manifest["id"]
        if dest.exists():
            shutil.rmtree(dest)
            notes.append("Updated existing mod.")
        if payload_to:
            (dest).mkdir(parents=True, exist_ok=True)
            shutil.move(str(payload_from), str(dest / payload_to))
        else:
            shutil.move(str(payload_from), str(dest))
        config.write_json(dest / "mod.json", manifest)
        mod = Mod(dest)
        if mod.needs_target():
            notes.append("Couldn't tell which chapter a patch is for - use SET TARGET.")
        return mod, notes
    finally:
        shutil.rmtree(work, ignore_errors=True)


def remove_mod(mod_id):
    d = config.MODS_DIR / mod_id
    if d.exists():
        shutil.rmtree(d)


# checking
# only checks whole-file clashes. two mods patching different parts of the
# same data.win still conflict - no way around that without merging
def find_conflicts(enabled_mods):
    """{mod_id: [(target, [other_ids])]} for enabled mods touching the same file."""
    by_target = {}
    for m in enabled_mods:
        for t in set(m.targets):
            by_target.setdefault(t, []).append(m.id)
    out = {}
    for t, ids in by_target.items():
        if len(ids) > 1 and t != UNKNOWN:
            for i in ids:
                out.setdefault(i, []).append((t, [o for o in ids if o != i]))
    return out


def find_xdelta(cfg):
    cands = []
    if cfg.get("xdelta_path"):
        cands.append(Path(cfg["xdelta_path"]))
    cands += sorted(config.TOOLS_DIR.glob("xdelta3*.exe")) + sorted(config.TOOLS_DIR.glob("xdelta3*"))
    which = shutil.which("xdelta3")
    if which:
        cands.append(Path(which))
    for c in cands:
        if c.is_file():
            return c
    return None


def check_mod(mod, game_dir, cfg, cache=None):
    """Returns (errors, warnings). Errors block applying."""
    errors, warnings = [], []
    game_dir = Path(game_dir) if game_dir else None
    against = mod.manifest.get("imported_against", {})
    for op in mod.operations:
        t = op.get("target", UNKNOWN)
        src_rel = Mod.source_of(op)
        if t in ("", UNKNOWN):
            errors.append("Patch target unknown - press SET TARGET.")
            continue
        if not (mod.dir / op.get("file", "")).exists():
            errors.append(f"Missing mod file {op.get('file')}")
        if op["type"] in ("xdelta", "replace") and t.endswith(".win"):
            if game_dir and not (game_dir / src_rel).exists() and not backup.has_vanilla(src_rel):
                errors.append(f"{src_rel} doesn't exist in your game - wrong build?")
                continue
            current = backup.vanilla_sha1(src_rel)
            if not current and game_dir and (game_dir / src_rel).exists():
                current = paths.sha1_file(game_dir / src_rel, cache)
            if op.get("expect_sha1"):
                if current and current != op["expect_sha1"]:
                    errors.append(f"VERSION MISMATCH on {t}: this patch was made for a "
                                  "different game build. It would crash.")
            elif against.get(src_rel) and current and against[src_rel] != current:
                warnings.append(f"Game updated since this mod was installed ({t}). "
                                "Get a newer version of the mod if it crashes.")
            elif op["type"] == "replace":
                warnings.append(f"Full data.win replacement - unverified for your build.")
        if op.get("expect_hash") and game_dir and t != UNKNOWN:
            source = (backup.vanilla_path(src_rel) if backup.has_vanilla(src_rel)
                      else game_dir / src_rel)
            algo = paths.HASH_BY_LENGTH.get(len(op["expect_hash"]))
            if not source.exists():
                errors.append(f"{t} doesn't exist in your game - this mod is for a different build.")
            elif algo and paths.hash_file(source, algo, cache) != op["expect_hash"].lower():
                errors.append(f"VERSION MISMATCH on {t}: this mod was made for a different game "
                              "version. Check for an update of the mod"
                              + ("." if backup.has_vanilla(t) else
                                 ", or verify the game in Steam if this file was modded by another tool."))
        if op["type"] == "bps" and game_dir:
            source = (backup.vanilla_path(src_rel) if backup.has_vanilla(src_rel)
                      else game_dir / src_rel)
            if not source.exists():
                errors.append(f"{src_rel} doesn't exist in your game - this mod is for a "
                              "different build (e.g. a newer chapter).")
            elif pick_bps(mod, op, source, cache) is None:
                if backup.has_vanilla(src_rel):
                    errors.append(f"VERSION MISMATCH on {src_rel}: none of this mod's patches were "
                                  "made for your game version. Get an updated version of the mod.")
                else:
                    errors.append(f"VERSION MISMATCH on {src_rel}: none of this mod's patches fit it. "
                                  "Either the mod is for another game version, or this file was "
                                  "already modded by another tool - verify the game in Steam.")
        if op["type"] == "xdelta" and not find_xdelta(cfg):
            errors.append("xdelta3 not found - put xdelta3.exe in the tools folder.")
    return sorted(set(errors)), sorted(set(warnings))


# applying
def sync_vanilla(game_dir, cache=None):
    """
    Detect Steam updates/verifies. If a game file no longer matches either our
    vanilla backup or what we last applied, Steam replaced it: adopt it as the
    new vanilla. Returns the list of refreshed files.
    """
    applied = config.read_json(config.APPLIED_FILE, {}).get("targets", {})
    man = backup.vanilla_manifest()
    refreshed = []
    for rel, entry in man.items():
        f = Path(game_dir) / rel
        if entry.get("absent") or not f.exists():
            continue
        sha = paths.sha1_file(f, cache)
        if sha != entry.get("sha1") and sha != applied.get(rel):
            backup.refresh_vanilla(game_dir, rel, cache)
            refreshed.append(rel)
    if refreshed:
        app = config.read_json(config.APPLIED_FILE, {})
        for rel in refreshed:
            app.get("targets", {}).pop(rel, None)
        config.write_json(config.APPLIED_FILE, app)
    return refreshed


def _run_xdelta(xdelta, src, patch, out):
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform.startswith("win") else 0
    res = subprocess.run([str(xdelta), "-d", "-f", "-s", str(src), str(patch), str(out)],
                         capture_output=True, text=True, creationflags=flags)
    if res.returncode != 0:
        msg = (res.stderr or res.stdout).strip()
        if "checksum" in msg.lower() or "source" in msg.lower():
            msg += "\n(This usually means the patch was made for a different game version.)"
        raise ModError(f"xdelta3 failed: {msg}")


def no_write_reason(game_dir, rels):
    """Why we can't write to the game folder, or None if we can."""
    game_dir = Path(game_dir)
    for rel in sorted({str(Path(r).parent) for r in rels}):
        folder = game_dir / rel if rel != "." else game_dir
        if not folder.exists():
            continue
        probe = folder / ".runemanager-write-test"
        try:
            probe.write_bytes(b"")
            probe.unlink()
        except OSError:
            return str(folder)
    return None


def permission_help(where):
    return (f"Windows won't let RuneManager write to:\n{where}\n\n"
            "Usually one of these:\n"
            "  - DELTARUNE is still open. Close it and try again.\n"
            "  - Steam is updating the game. Let it finish.\n"
            "  - Your account can't write to that folder. Right-click "
            "RuneManager and pick 'Run as administrator', or move the game to a "
            "Steam library outside Program Files.")


def apply_loadout(game_dir, mods_by_id, enabled_order, cfg, cache=None, log=print):
    """Rebuild the game files: vanilla first, then each enabled mod in order."""
    game_dir = Path(game_dir)
    enabled = [mods_by_id[i] for i in enabled_order if i in mods_by_id]

    conflicts = find_conflicts(enabled)
    if conflicts:
        names = ", ".join(mods_by_id[i].name for i in conflicts)
        raise ModError(f"Conflicting mods are enabled: {names}. Disable one of them.")
    for m in enabled:
        errors, _ = check_mod(m, game_dir, cfg, cache)
        if errors:
            raise ModError(f"{m.name}: " + " / ".join(errors))

    log("Checking for game updates...")
    refreshed = sync_vanilla(game_dir, cache)
    if refreshed:
        log("Game files changed since last time, adopted as new vanilla: " + ", ".join(refreshed))

    applied = config.read_json(config.APPLIED_FILE, {})
    prev = set(applied.get("targets", {}))
    new = {op["target"] for m in enabled for op in m.operations}
    sources = {Mod.source_of(op) for m in enabled for op in m.operations}
    touched = prev | new

    blocked = no_write_reason(game_dir, new | sources)
    if blocked:
        raise ModError(permission_help(blocked))

    try:
        backup.backup_many(game_dir, sorted(new | sources), cache, log)
        man = backup.vanilla_manifest()
        log("Restoring vanilla files...")
        for rel in sorted(touched):
            if rel in man:
                backup.restore_vanilla_file(game_dir, rel, man)
    except PermissionError as exc:
        raise ModError(permission_help(getattr(exc, "filename", game_dir))) from exc

    xdelta = find_xdelta(cfg)
    try:
        for m in enabled:
            for op in m.operations:
                rel, src_file = op["target"], m.dir / op["file"]
                src_rel = m.source_of(op)
                target = game_dir / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                tmp = target.with_name(target.name + ".vessel-tmp")
                if op["type"] != "copy" or rel.endswith(".win"):
                    extra = f" (from {src_rel})" if src_rel != rel else ""
                    log(f"{m.name}: {op['type']} -> {rel}{extra}")
                if op["type"] == "xdelta":
                    _run_xdelta(xdelta, backup.vanilla_path(src_rel), src_file, tmp)
                elif op["type"] == "bps":
                    chosen = pick_bps(m, op, backup.vanilla_path(src_rel), cache)
                    if chosen is None:
                        raise ModError(f"{m.name}: no patch fits your {src_rel}.")
                    log(f"   using {chosen.name}")
                    bps.apply(backup.vanilla_path(src_rel), chosen, tmp)
                else:
                    shutil.copy2(src_file, tmp)
                os.replace(tmp, target)
    except Exception as exc:
        log("Something failed - rolling back to vanilla.")
        for rel in sorted(touched):
            if rel in man:
                try:
                    backup.restore_vanilla_file(game_dir, rel, man)
                except OSError:
                    pass
        config.write_json(config.APPLIED_FILE, {})
        if isinstance(exc, PermissionError):
            raise ModError(permission_help(getattr(exc, "filename", game_dir))) from exc
        raise

    copies = sum(1 for m in enabled for op in m.operations if op["type"] == "copy")
    if copies:
        log(f"Copied {copies} file(s).")
    record = {"enabled": [m.id for m in enabled], "targets": {}}
    for rel in new:
        f = game_dir / rel
        if f.exists():
            record["targets"][rel] = paths.sha1_file(f, cache)
    config.write_json(config.APPLIED_FILE, record)
    log(f"Done. {len(enabled)} mod(s) active.")
    return len(enabled)


def files_needing_checksum(mods_list, game_dir, cache):
    """(file, algo) pairs a version check would have to read that aren't cached yet."""
    out = []
    if not game_dir:
        return out
    for m in mods_list:
        for op in m.operations:
            t = op.get("target")
            if t in (None, "", UNKNOWN):
                continue
            jobs = []
            if op.get("type") == "bps":
                jobs.append("crc")
            algo = paths.HASH_BY_LENGTH.get(len(op.get("expect_hash") or ""))
            if algo:
                jobs.append(algo)
            if not jobs:
                continue
            src_rel = Mod.source_of(op)
            f = (backup.vanilla_path(src_rel) if backup.has_vanilla(src_rel)
                 else Path(game_dir) / src_rel)
            if not f.exists():
                continue
            for algo in jobs:
                if not paths.is_cached(f, algo, cache) and (f, algo) not in out:
                    out.append((f, algo))
    return out


def warm_checksums(jobs, cache):
    """Fill `cache` with the checksums in `jobs` [(file, algo)] and return it."""
    for f, algo in jobs:
        if algo == "crc":
            bps.crc32_file(f, cache)
        else:
            paths.hash_file(f, algo, cache)
    return cache


def _match_requirement(req, mods_by_id):
    """The installed mod a requirement points at, if we have it."""
    refs = [req.get("url"), req.get("ref")]
    if req.get("kind") == "gamebanana" and req.get("ref"):
        # the ref is a bare mod id; compare whole urls so "701" can't match "70123"
        refs.append(f"https://gamebanana.com/mods/{req['ref']}")
    for ref in refs:
        ref = str(ref or "").strip().lower().rstrip("/")
        if not ref or ref.isdigit():
            continue
        for other in mods_by_id.values():
            src = (other.source_url or "").strip().lower().rstrip("/")
            if src and (src == ref or ref in src or src in ref):
                return other
    return None


def missing_requirements(mod, mods_by_id, enabled_ids):
    """Requirements of `mod` that aren't installed, or are installed but switched off."""
    out = []
    for req in mod.requires:
        if req.get("level") == "optional":
            continue
        other = _match_requirement(req, mods_by_id)
        if other is None:
            out.append((req, "not installed"))
        elif other.id not in enabled_ids:
            out.append((req, "installed but switched off"))
    return out


def sort_by_requirements(order, mods_by_id):
    """A mod that needs another has to be applied after it, so move the ones it
    needs in front. Leaves everything else where it was."""
    order = [i for i in order if i in mods_by_id]
    for _ in range(len(order) + 1):
        moved = False
        for mod_id in list(order):
            for req in mods_by_id[mod_id].requires:
                dep = _match_requirement(req, mods_by_id)
                if dep is None or dep.id == mod_id or dep.id not in order:
                    continue
                if order.index(dep.id) > order.index(mod_id):
                    order.remove(dep.id)
                    order.insert(order.index(mod_id), dep.id)
                    moved = True
        if not moved:
            break
    return order
