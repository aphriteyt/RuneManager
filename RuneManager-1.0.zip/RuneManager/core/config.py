"""Folder layout + the settings file."""
import json
import os
import sys
import threading
from pathlib import Path

# frozen = running as the .exe, so keep data next to it not in the temp unpack
if getattr(sys, "frozen", False):
    APP_DIR = Path(sys.executable).resolve().parent
else:
    APP_DIR = Path(__file__).resolve().parent.parent
MODS_DIR = APP_DIR / "mods"
BACKUP_DIR = APP_DIR / "backups"
VANILLA_DIR = BACKUP_DIR / "vanilla"
SAVE_SNAP_DIR = BACKUP_DIR / "saves"
TOOLS_DIR = APP_DIR / "tools"
DATA_DIR = APP_DIR / "data"
TEMP_DIR = APP_DIR / "temp"

CONFIG_FILE = DATA_DIR / "config.json"
CATALOG_FILE = DATA_DIR / "catalog.json"
PRESETS_FILE = DATA_DIR / "secret_presets.json"
LABELS_FILE = DATA_DIR / "save_labels.json"
APPLIED_FILE = DATA_DIR / "applied.json"
BUILDS_FILE = DATA_DIR / "known_builds.json"

DEFAULT_CONFIG = {
    "game_dir": "",
    "xdelta_path": "",
    "load_order": [],      # every installed mod id, in priority order
    "enabled": [],         # ids the user has ticked
    "hash_cache": {},      # path -> [size, mtime, sha1]  (speeds up startup)
    "background_motion": False,   # drifting background (off: no repaint cost)
}

CATALOG_VERSION = 2
CURATED_CATALOG = [
    {"name": "FLB Practice Mod", "author": "nhaar", "category": "GAMEPLAY",
     "description": "Speedrun & no-hit practice: save states, timers, warps, hitbox and "
                    "frame tools. Right-click in-game opens its menu.",
     "url": "github:nhaar/flb-mod"},
    {"name": "Custom Difficulty", "author": "Emmahaha", "category": "GAMEPLAY",
     "description": "Adds Easy, Hard and Nightmare difficulty plus no-hit options, "
                    "chosen from an in-game menu.",
     "url": "github:Emmehehe/CustomDifficultyModForDeltarune",
     "asset": "datapack_difficulty_dr-fullgame"},
    {"name": "Archipelago Randomizer", "author": "Tenebrosful", "category": "GAMEPLAY",
     "description": "Solo or multiplayer item randomizer. Needs the Archipelago client "
                    "to connect to a game (archipelago.gg).",
     "url": "github:Tenebrosful/DeltaruneAP-mod", "asset": r"_xdelta\.zip$"},
    {"name": "Musicless Deltarune", "author": "AGamer20", "category": "AUDIO",
     "description": "Replaces every music track with silence - play your own music. "
                    "Sound effects stay.",
     "url": "github:AGamer20/Musicless-Deltarune"},
    {"name": "Deltranslate", "author": "Lazy-Desman / Neprim", "category": "LANGUAGE",
     "description": "Adds an in-game language menu so community translation packs "
                    "can be switched without reinstalling.",
     "url": "github:Lazy-Desman/DeltranslatePatch", "asset": r"^Deltranslate.*\.zip$"},
    {"name": "Ukrainian Translation", "author": "Pereclaw", "category": "LANGUAGE",
     "description": "Ukrainian (Українська) translation. Chapters 1-3 complete, "
                    "4-5 in progress.",
     "url": "github:Pereclaw/deltarune-ua", "asset": r"LTS_Release-UA_Win"},
    {"name": "Chinese Translation", "author": "gm3dr", "category": "LANGUAGE",
     "description": "Full Simplified Chinese (简体中文) translation of every chapter.",
     "url": "github:gm3dr/DeltaruneChinese", "asset": r"patch_chs_windowslinux_\d+\.7z$"},
    {"name": "Brazilian Portuguese", "author": "Equipe Teiarruma", "category": "LANGUAGE",
     "description": "PT-BR translation with voice dubbing, Chapters 1-4. "
                    "Large download (~240 MB).",
     "url": "github:teiarruma/deltarune-ptbr", "asset": r"pago_PTBR.*Windows\.zip$"},
]

_lock = threading.Lock()


def ensure_dirs():
    if TEMP_DIR.exists():
        import shutil
        for leftover in TEMP_DIR.iterdir():
            if leftover.is_dir():
                shutil.rmtree(leftover, ignore_errors=True)
    for d in (MODS_DIR, BACKUP_DIR, VANILLA_DIR, SAVE_SNAP_DIR,
              TOOLS_DIR, DATA_DIR, TEMP_DIR):
        d.mkdir(parents=True, exist_ok=True)
    _seed_catalog()
    if not PRESETS_FILE.exists():
        write_json(PRESETS_FILE, [])
    if not LABELS_FILE.exists():
        write_json(LABELS_FILE, {})
    if not BUILDS_FILE.exists():
        write_json(BUILDS_FILE, {})


def _seed_catalog():
    """Add the built-in buttons once per catalog version, keep the user's own."""
    cat = read_json(CATALOG_FILE, None)
    cfg = read_json(CONFIG_FILE, {})
    if cat is not None and cfg.get("catalog_version", 0) >= CATALOG_VERSION:
        return
    cat = [e for e in (cat or []) if e.get("url") or not str(e.get("name", "")).startswith("YOUR MOD SLOT")]

    def key(url):
        return url.lower().replace("https://github.com/", "github:").rstrip("/")
    have = {key(e.get("url", "")): e for e in cat}
    for entry in CURATED_CATALOG:
        if key(entry["url"]) in have:
            have[key(entry["url"])].update(
                {k: v for k, v in entry.items() if k not in ("name", "url")})
        else:
            cat.append(dict(entry))
    write_json(CATALOG_FILE, cat)
    cfg["catalog_version"] = CATALOG_VERSION
    write_json(CONFIG_FILE, cfg)


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def write_json(path, data):
    """Atomic write: write to .tmp then rename, so a crash never leaves half a file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, path)


class Config:
    """Thread-safe settings object. Call .save() after changing values."""

    def __init__(self):
        data = read_json(CONFIG_FILE, {})
        self.data = dict(DEFAULT_CONFIG)
        self.data.update(data)

    def __getitem__(self, key):
        return self.data[key]

    def __setitem__(self, key, value):
        self.data[key] = value

    def get(self, key, default=None):
        return self.data.get(key, default)

    def save(self):
        with _lock:
            write_json(CONFIG_FILE, self.data)
