"""GameBanana API. DELTARUNE is game 6755 there."""
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path

from . import config

GAME_ID = 6755
API = "https://gamebanana.com/apiv11"
PER_PAGE = 15
UA = {"User-Agent": "RuneManager/1.0 (Deltarune mod manager)"}

SORTS = {
    "NEWEST": "Generic_Newest",
    "UPDATED": "Generic_LatestModified",
    "POPULAR": "Generic_MostDownloaded",
    "LIKED": "Generic_MostLiked",
}

_cache = {}
CACHE_SECONDS = 300


class GBError(Exception):
    pass


class Cancelled(Exception):
    pass


def _get(url, use_cache=True):
    hit = _cache.get(url)
    if use_cache and hit and time.time() - hit[0] < CACHE_SECONDS:
        return hit[1]
    req = urllib.request.Request(url, headers={**UA, "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=25) as r:
            raw = r.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        if exc.code in (429, 503):
            raise GBError("GameBanana is busy or rate-limiting us. Wait a minute "
                          "and try again.")
        raise GBError(f"GameBanana returned error {exc.code}.")
    except Exception as exc:
        raise GBError(f"Couldn't reach GameBanana: {exc}")
    try:
        data = json.loads(raw)
    except ValueError:
        raise GBError("GameBanana sent something that isn't JSON (it may be down).")
    _cache[url] = (time.time(), data)
    return data


def _clean(text):
    text = re.sub(r"<[^>]+>", "", str(text or ""))
    import html
    return html.unescape(text).strip()


def _record(r):
    """Turn one API record into the small dict the UI uses."""
    media = (r.get("_aPreviewMedia") or {}).get("_aImages") or []
    thumb = ""
    if media:
        m = media[0]
        if m.get("_sBaseUrl") and m.get("_sFile220"):
            thumb = f"{m['_sBaseUrl']}/{m['_sFile220']}"
    return {
        "id": r.get("_idRow"),
        "name": _clean(r.get("_sName")) or "(untitled)",
        "author": _clean((r.get("_aSubmitter") or {}).get("_sName")) or "unknown",
        "category": _clean((r.get("_aRootCategory") or {}).get("_sName")),
        "updated": time.strftime("%Y-%m-%d", time.localtime(
            r.get("_tsDateModified") or r.get("_tsDateAdded") or 0)),
        "likes": r.get("_nLikeCount") or 0,
        "views": r.get("_nViewCount") or 0,
        "has_files": bool(r.get("_bHasFiles")),
        "url": r.get("_sProfileUrl") or f"https://gamebanana.com/mods/{r.get('_idRow')}",
        "thumb": thumb,
    }


def browse(page=1, sort="UPDATED"):
    """One page of DELTARUNE mods. Returns (records, total_pages)."""
    q = urllib.parse.urlencode({
        "_nPage": max(1, int(page)), "_nPerpage": PER_PAGE,
        "_aFilters[Generic_Game]": GAME_ID,
        "_sSort": SORTS.get(sort, SORTS["UPDATED"]),
    })
    data = _get(f"{API}/Mod/Index?{q}")
    records = [_record(r) for r in data.get("_aRecords", [])]
    total = (data.get("_aMetadata") or {}).get("_nRecordCount") or len(records)
    return records, max(1, -(-int(total) // PER_PAGE))


def search(text, page=1):
    """Search DELTARUNE mods by name. Returns (records, total_pages)."""
    text = (text or "").strip()
    if not text:
        return browse(page)
    q = urllib.parse.urlencode({
        "_sSearchString": text, "_idGameRow": GAME_ID, "_sModelName": "Mod",
        "_nPage": max(1, int(page)), "_nPerpage": PER_PAGE,
    })
    data = _get(f"{API}/Util/Search/Results?{q}")
    records = [_record(r) for r in data.get("_aRecords", [])
               if r.get("_sModelName") == "Mod"]
    total = (data.get("_aMetadata") or {}).get("_nRecordCount") or len(records)
    return records, max(1, -(-int(total) // PER_PAGE))


def files(mod_id):
    """Downloadable files for a mod, newest first. Each is a dict for the UI."""
    data = _get(f"{API}/Mod/{int(mod_id)}/DownloadPage", use_cache=False)
    if data.get("_bIsTrashed") or data.get("_bIsWithheld"):
        raise GBError("That mod has been taken down on GameBanana.")
    out = []
    for f in data.get("_aFiles") or []:
        out.append({
            "id": f.get("_idRow"),
            "name": _clean(f.get("_sFile")) or "file",
            "size": f.get("_nFilesize") or 0,
            "url": f.get("_sDownloadUrl") or f"https://gamebanana.com/dl/{f.get('_idRow')}",
            "version": _clean(f.get("_sVersion")),
            "description": _clean(f.get("_sDescription")),
            "md5": (f.get("_sMd5Checksum") or "").lower(),
            # GameBanana scans uploads; anything not "clean" is worth warning about
            "clean": (f.get("_sAvResult") or "").lower() in ("clean", ""),
            "checked": (f.get("_sAvState") or "").lower() == "done",
            "added": f.get("_tsDateAdded") or 0,
        })
    out.sort(key=lambda f: f["added"], reverse=True)
    if not out:
        raise GBError("That mod has no downloadable files (it may link somewhere else).")
    return out


INSTALLABLE = (".zip", ".7z", ".rar", ".xdelta", ".vcdiff", ".bps", ".win", ".dll")


# guesswork. the chooser dialog is there for when this gets it wrong
def best_file(file_list):
    """The file most likely to be the PC mod: an archive, not a Mac/Switch build."""
    usable = [f for f in file_list if f["name"].lower().endswith(INSTALLABLE)]
    if not usable:
        return None
    bad = re.compile(r"mac|osx|linux|switch|android|\.apk|source|wallpaper", re.I)
    good = [f for f in usable if not bad.search(f["name"])] or usable
    good.sort(key=lambda f: (not f["name"].lower().endswith((".zip", ".7z", ".rar")),
                             -f["added"]))
    return good[0]


def download(file_entry, progress=None, cancel_event=None):
    """Download one file into a fresh temp folder. Returns the local path."""
    out_dir = config.TEMP_DIR / ("gb_" + uuid.uuid4().hex[:8])
    out_dir.mkdir(parents=True, exist_ok=True)
    name = re.sub(r'[\\/:*?"<>|]', "_", file_entry["name"]) or "mod.zip"
    out = out_dir / name
    req = urllib.request.Request(file_entry["url"], headers={
        **UA, "Accept": "*/*", "Referer": "https://gamebanana.com/"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            ctype = (r.headers.get("Content-Type") or "").lower()
            if "text/html" in ctype:
                raise GBError("GameBanana returned a web page instead of the file. "
                              "Open the mod page and download it yourself, then use "
                              "IMPORT MOD FILE in the MODS tab.")
            total = int(r.headers.get("Content-Length") or file_entry.get("size") or 0)
            done = 0
            with open(out, "wb") as f:
                while True:
                    if cancel_event is not None and cancel_event.is_set():
                        raise Cancelled()
                    chunk = r.read(256 * 1024)
                    if not chunk:
                        break
                    f.write(chunk)
                    done += len(chunk)
                    if progress:
                        progress(done, total)
    except (GBError, Cancelled):
        raise
    except Exception as exc:
        raise GBError(f"Download failed: {exc}")
    if file_entry.get("md5"):
        import hashlib
        h = hashlib.md5()
        with open(out, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        if h.hexdigest() != file_entry["md5"]:
            raise GBError("The download didn't arrive intact (checksum mismatch). "
                          "Try again.")
    return out


# requirements: [name, url, status, colour, "Required"/"Recommended", colour]
GB_MOD_URL = re.compile(r"gamebanana\.com/mods/(\d+)", re.I)
GITHUB_URL = re.compile(r"^https?://github\.com/[\w.\-]+/[\w.\-]+/?$", re.I)
# things listed as requirements that aren't mods we could install
NOT_A_MOD = re.compile(r"steampowered|deltarune\.com|gog\.com|/tools/|/wips/|undertalemodtool|"
                       r"utmt|python|\.net|visual c|winrar|7-?zip|archipelago\.gg|discord\.gg", re.I)


def requirements(mod_id):
    """What a mod says it needs. Jokes and 'you need the game' entries are dropped."""
    data = _get(f"{API}/Mod/{int(mod_id)}/ProfilePage")
    out = []
    for row in data.get("_aRequirements") or []:
        if not isinstance(row, (list, tuple)) or not row:
            continue
        name = _clean(row[0])
        url = _clean(row[1]) if len(row) > 1 else ""
        # no link means there's nothing to act on - usually a joke entry
        # ("a computer that boots") or "you need the game", which they do have
        if not name or not url.startswith("http"):
            continue
        if NOT_A_MOD.search(url) or NOT_A_MOD.search(name):
            continue
        level = "required"
        for extra in row[2:]:
            if str(extra).lower() in ("required", "recommended", "optional"):
                level = str(extra).lower()
        kind, ref = "other", ""
        m = GB_MOD_URL.search(url)
        if m:
            kind, ref = "gamebanana", int(m.group(1))
        elif GITHUB_URL.match(url.rstrip("/")):
            kind, ref = "github", "github:" + "/".join(url.rstrip("/").split("/")[-2:])
        out.append({"name": name, "url": url, "level": level, "kind": kind, "ref": ref})
    return out


def mod_info(mod_id):
    """Name + author for a mod we only know the id of."""
    data = _get(f"{API}/Mod/{int(mod_id)}/ProfilePage")
    return {
        "id": int(mod_id),
        "name": _clean(data.get("_sName")) or f"mod {mod_id}",
        "author": _clean((data.get("_aSubmitter") or {}).get("_sName")) or "unknown",
        "url": data.get("_sProfileUrl") or f"https://gamebanana.com/mods/{mod_id}",
        "has_files": True,
    }
