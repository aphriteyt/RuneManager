Installed mods appear here, one folder each.
Add them from the DOWNLOAD tab, or MODS -> IMPORT MOD FILE.
