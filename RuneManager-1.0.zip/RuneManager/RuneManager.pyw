"""Double-click this file to open RuneManager (no console window)."""
import runpy
from pathlib import Path

runpy.run_path(str(Path(__file__).resolve().parent / "main.py"), run_name="__main__")
