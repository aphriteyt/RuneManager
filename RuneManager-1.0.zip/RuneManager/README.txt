RuneManager - a mod manager for DELTARUNE
=========================================

QUICK START
  1. Double-click RuneManager.exe
  2. Game tab - it should find your Steam copy of DELTARUNE by itself.
     If not, press BROWSE FOLDER and point it at your DELTARUNE folder.
  3. DOWNLOAD tab - press a button to install a mod automatically.
  4. MODS tab - tick what you want, then press APPLY CHANGES.
  5. Game tab - LAUNCH DELTARUNE.

IF WINDOWS BLOCKS RuneManager.exe
  Some PCs have Smart App Control switched on, which refuses to run any app
  that hasn't been code-signed (signing costs money, and this is free). If
  you get "blocked an app that may be unsafe", use the Python version
  instead - it is the same program:
    1. Install Python from python.org. On the first installer screen TICK
       "Add python.exe to PATH", then click Install Now.
    2. Double-click RuneManager.pyw in this folder.
  If you instead get "Windows protected your PC" with a More info link,
  that one is fine: More info -> Run anyway.

FOR .XDELTA MODS
  Put xdelta3.exe in the tools folder (see tools\README.txt).
  Mods that use .bps patches work with no extra download.

YOUR GAME IS SAFE
  Before touching anything, RuneManager copies your untouched game files and
  your save files into backups\. Turning a mod off rebuilds the game from
  those copies, so mods never stack on top of each other.
  GAME -> RESTORE VANILLA GAME   puts the game back to normal
  GAME -> RESTORE SAVE FILE      puts your saves back

THE TABS
  GAME      find the game, back up and restore, launch it
  MODS      turn mods on/off, see conflicts, APPLY
  DOWNLOAD  one-click installs; FIND MORE MODS searches GitHub
  BROWSE    search all of GameBanana's Deltarune mods and install one
            with a single press. If a mod needs another, it offers to
            install that too
  SAVES     edit a save file (find a value, name it, change it)
  PRESETS   record save values and write them back later
  SHARE     turn your mod list into a GONER- code to send to a friend

WHAT IT CAN INSTALL
  .xdelta and .bps patches, full data.win files, loose game files, and .zip,
  .7z or .rar archives of any of those. It understands Deltamod/G3M packages
  (modding.xml / meta.toml), including their version checksums, so a mod
  built for a different game version is blocked instead of crashing you.
  It can NOT run mods that need UndertaleModTool scripts (.csx) or their own
  installer program - those have to be done by hand.

IF SOMETHING GOES WRONG
  GAME -> RESTORE VANILLA GAME
  Steam -> DELTARUNE -> Properties -> Installed Files -> Verify
  A crash.log file appears next to RuneManager.exe if the app itself crashes.

RuneManager is a fan tool. It doesn't include any part of DELTARUNE, and it
doesn't host anyone's mods - every download comes from that mod author's own
release page. DELTARUNE is by Toby Fox.
