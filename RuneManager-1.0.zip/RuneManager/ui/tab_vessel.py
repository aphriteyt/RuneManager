"""GAME tab - game folder, backups, launch."""
import tkinter as tk
from tkinter import filedialog

from core import backup, config, mods, paths
from . import theme
from .app import Tab


def choose_snapshot(app):
    """Themed picker for a save snapshot. Returns the name or None."""
    snaps = backup.list_snapshots()
    if not snaps:
        theme.info(app.root, "No backups yet",
                   "There are no save backups yet. Press BACKUP SAVES NOW first.")
        return None
    options = [f"{n[:19].replace('_', '  ')}   {reason:<16} {count} files"
               for n, reason, count in snaps]
    i = theme.choose(app.root, "Restore save file",
                     "Pick a backup (newest at the top). Your current saves are backed up "
                     "again before anything is overwritten.", options, ok="RESTORE", height=12)
    return None if i is None else snaps[i][0]


class VesselTab(Tab):
    requires_game = False

    def build(self):
        self.scroll = theme.ScrollFrame(self)
        self.scroll.pack(fill="both", expand=True)
        page = self.scroll.inner
        self.lock_box = tk.Frame(page, bg=theme.RED, padx=2, pady=2)
        lb = tk.Frame(self.lock_box, bg=theme.BG, padx=16, pady=12)
        lb.pack(fill="x")
        theme.label(lb, "ACCESS LOCKED", 14, theme.RED, True).pack(anchor="w")
        self.lock_msg = theme.label(lb, "", 10, theme.FG, wraplength=900)
        self.lock_msg.pack(anchor="w", pady=(4, 8))
        theme.GButton(lb, "RESCAN", self.rescan, danger=True).pack(anchor="w")

        cols = tk.Frame(page, bg=theme.BG)
        cols.pack(fill="both", expand=True, padx=(0, 10))
        right = tk.Frame(cols, bg=theme.BG)
        right.pack(side="right", fill="y")
        left = tk.Frame(cols, bg=theme.BG)
        left.pack(side="left", fill="both", expand=True, padx=(0, 24))
        self.cols = cols

        # left: game folder + build info
        self.heading(left, "GAME FOLDER", "Where DELTARUNE is installed.")
        self.path_lbl = theme.label(left, "-", 10, theme.FG, wraplength=600)
        self.path_lbl.pack(anchor="w")
        row = tk.Frame(left, bg=theme.BG)
        row.pack(anchor="w", pady=10)
        theme.GButton(row, "AUTO-DETECT", self.auto).pack(side="left", padx=(0, 8))
        theme.GButton(row, "BROWSE FOLDER", self.browse_dir).pack(side="left", padx=(0, 8))
        theme.GButton(row, "PICK DATA.WIN / EXE", self.browse_file).pack(side="left")
        self.legit_lbl = theme.label(left, "", 10, theme.DIM, wraplength=600)
        self.legit_lbl.pack(anchor="w", pady=(4, 10))

        theme.label(left, "GAME FILES", 11, theme.FG, True).pack(anchor="w")
        theme.label(left, "Checked against each mod, so a mismatched patch is refused.",
                    9, theme.DIM, wraplength=600).pack(anchor="w", pady=(2, 6))
        self.builds = theme.textbox(left, height=5, wrap="none")
        self.builds.pack(fill="x")
        self.builds.config(state="disabled")

        theme.label(left, "PATCH TOOL (xdelta3)", 11, theme.FG, True).pack(anchor="w", pady=(14, 2))
        self.xd_lbl = theme.label(left, "", 10, theme.DIM, wraplength=600)
        self.xd_lbl.pack(anchor="w")
        row2 = tk.Frame(left, bg=theme.BG)
        row2.pack(anchor="w", pady=8)
        theme.GButton(row2, "LOCATE xdelta3.exe", self.locate_xdelta).pack(side="left", padx=(0, 8))
        theme.GButton(row2, "OPEN TOOLS FOLDER",
                      lambda: paths.open_folder(config.TOOLS_DIR)).pack(side="left")

        # right: safety
        self.heading(right, "BACKUPS", "")
        theme.GButton(right, "RESTORE SAVE FILE", self.restore_saves, big=True,
                      width=22).pack(anchor="w", pady=(0, 10))
        theme.GButton(right, "BACKUP SAVES NOW", self.backup_now, width=30).pack(anchor="w", pady=3)
        theme.GButton(right, "RESTORE VANILLA GAME", self.restore_vanilla, width=30).pack(anchor="w", pady=3)
        theme.GButton(right, "OPEN BACKUPS FOLDER",
                      lambda: paths.open_folder(config.BACKUP_DIR), width=30).pack(anchor="w", pady=3)
        theme.GButton(right, "OPEN SAVE FOLDER", self.open_saves, width=30).pack(anchor="w", pady=3)
        theme.rule(right).pack(fill="x", pady=8)
        theme.label(right, "APPEARANCE", 11, theme.FG, True).pack(anchor="w")
        theme.label(right, "Use your own image behind the window (PNG or GIF).",
                    9, theme.DIM, wraplength=int(300 * self.app.s)).pack(anchor="w")
        self.bg_btn = theme.GButton(right, "SET BACKGROUND IMAGE", self.set_background, width=30)
        self.bg_btn.pack(anchor="w", pady=3)
        self.snap_lbl = theme.label(right, "", 9, theme.DIM, wraplength=320)
        self.snap_lbl.pack(anchor="w", pady=(10, 14))
        self.launch_btn = theme.GButton(right, "LAUNCH DELTARUNE", self.launch, huge=True)
        self.launch_btn.pack(anchor="w", pady=(8, 0))

    # refresh
    def refresh(self):
        app = self.app
        gd = app.game_dir
        self.path_lbl.config(text=str(gd) if gd else "NOT FOUND - browse to your DELTARUNE folder.")
        if app.is_locked():
            self.lock_msg.config(text=app.legit[1][0] + "\n\nThis manager only works with a "
                                 "genuine copy. Delete those files (or reinstall / verify the game "
                                 "in Steam), then press RESCAN. The Chapter 1&2 demo is free.")
            self.lock_box.pack(fill="x", pady=(0, 14), before=self.cols)
            self.legit_lbl.config(text="AUTHENTICITY: FAILED", fg=theme.RED)
        else:
            self.lock_box.pack_forget()
            if gd:
                self.legit_lbl.config(text="AUTHENTICITY: OK.  " + " ".join(app.legit[1]),
                                      fg=theme.DIM)
            else:
                self.legit_lbl.config(text="", fg=theme.DIM)
        self.launch_btn.set_enabled(bool(gd) and not app.is_locked())

        xd = mods.find_xdelta(app.cfg)
        self.xd_lbl.config(
            text=f"Found: {xd}" if xd else
            "NOT FOUND. Needed for .xdelta patch mods (most Deltarune mods). "
            "Download xdelta3 and drop xdelta3.exe into the tools folder.",
            fg=theme.DIM if xd else theme.RED)

        snaps = backup.list_snapshots()
        self.snap_lbl.config(text=(f"{len(snaps)} save backup(s). Latest: {snaps[0][0][:19]}"
                                   if snaps else "No save backups yet."))
        self._write_builds("measuring..." if gd else "")
        if gd:
            app.run_bg(self._fingerprint, self._write_builds)

    def _fingerprint(self):
        gd = self.app.game_dir
        known = config.read_json(config.BUILDS_FILE, {})
        lines = []
        for rel in paths.find_data_wins(gd):
            f = gd / rel
            sha = paths.sha1_file(f, self.app.cache)
            van = backup.vanilla_sha1(rel)
            state = ("vanilla (backed up)" if van == sha else
                     "MODDED (vanilla kept safe)" if van else "not backed up yet")
            name = known.get(sha, "")
            lines.append(f"{rel:<28} {f.stat().st_size / 1048576:7.1f} MB  "
                         f"{sha[:12]}  {state}{'  ' + name if name else ''}")
        self.app.cfg.save()
        return "\n".join(lines) or "No data.win files found."

    def _write_builds(self, text):
        if not self.builds.winfo_exists():
            return
        self.builds.config(state="normal")
        self.builds.delete("1.0", "end")
        self.builds.insert("1.0", text)
        self.builds.config(state="disabled")

    # actions
    def auto(self):
        found = paths.auto_detect_game()
        if found:
            self.app.set_game_dir(found)
        else:
            theme.info(self.app.root, "Not found",
                       "Couldn't find Deltarune in any Steam library. Use BROWSE FOLDER.")

    def browse_dir(self):
        d = filedialog.askdirectory(title="Select your DELTARUNE folder")
        if d:
            self.app.set_game_dir(d)

    def browse_file(self):
        f = filedialog.askopenfilename(title="Select data.win or DELTARUNE.exe",
                                       filetypes=[("Deltarune files", "*.win *.exe"),
                                                  ("All files", "*.*")])
        if f:
            self.app.set_game_dir(f)

    def rescan(self):
        if self.app.game_dir:
            self.app.set_game_dir(self.app.game_dir)

    def locate_xdelta(self):
        f = filedialog.askopenfilename(title="Select xdelta3.exe",
                                       filetypes=[("Programs", "*.exe"), ("All files", "*.*")])
        if f:
            self.app.cfg["xdelta_path"] = f
            self.app.cfg.save()
            self.app.refresh_all()

    def backup_now(self):
        name = backup.snapshot_saves("manual")
        if name:
            self.app.say("Saves backed up.")
        else:
            theme.info(self.app.root, "No saves", f"No save files found in\n{paths.save_dir()}")
        self.refresh()

    def restore_saves(self):
        name = choose_snapshot(self.app)
        if not name:
            return
        try:
            n = backup.restore_snapshot(name)
            self.app.say(f"Restored {n} save file(s).")
        except Exception as exc:
            theme.error(self.app.root, "Restore failed", str(exc))
        self.app.refresh_all()

    def restore_vanilla(self):
        if not self.app.game_dir:
            return
        if not theme.confirm(self.app.root, "Restore vanilla game",
                             "Turn off ALL mods and put every game file back exactly as it was?"):
            return
        n = backup.restore_all_vanilla(self.app.game_dir)
        self.app.cfg["enabled"] = []
        self.app.cfg.save()
        self.app.say(f"Game restored to vanilla ({n} files).")
        self.app.refresh_all()

    def set_background(self):
        from .background import CUSTOM_BG
        if CUSTOM_BG.exists():
            choice = theme.ask(self.app.root, "Background image",
                               "You're using your own background image.",
                               ("CHOOSE ANOTHER", "USE THE DEFAULT", "CANCEL"))
            if choice == "CANCEL" or choice is None:
                return
            if choice == "USE THE DEFAULT":
                CUSTOM_BG.unlink(missing_ok=True)
                self.app.bg.reload_custom()
                self.app.say("Using the default background.")
                return
        f = filedialog.askopenfilename(title="Choose a background image",
                                       filetypes=[("Images", "*.png *.gif"), ("All files", "*.*")])
        if not f:
            return
        try:
            import shutil
            import tkinter as tk_
            tk_.PhotoImage(file=f)          # fails early if Tk can't read it
            CUSTOM_BG.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, CUSTOM_BG)
            self.app.bg.reload_custom()
        except Exception:
            theme.error(self.app.root, "Can't use that image",
                        "Only PNG and GIF images work here. Save yours as a .png and try again.")
            return
        self.app.say("Background changed.")

    def open_saves(self):
        d = paths.save_dir()
        if d.exists():
            paths.open_folder(d)
        else:
            theme.info(self.app.root, "No save folder", f"{d}\ndoesn't exist yet - play once first.")

    def launch(self):
        try:
            paths.launch_game(self.app.game_dir)
            self.app.say("Launching Deltarune...")
        except Exception as exc:
            theme.error(self.app.root, "Couldn't launch", str(exc))
