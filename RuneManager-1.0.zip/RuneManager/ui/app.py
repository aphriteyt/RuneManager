"""Main window: background canvas, header, tabs."""
import queue
import threading
import tkinter as tk
import traceback
from pathlib import Path

from core import config, mods, paths
from . import pixelfont as pf
from . import theme
from .background import Background

TABS = ["GAME", "MODS", "DOWNLOAD", "BROWSE", "SAVES", "PRESETS", "SHARE"]


class VesselApp:
    def __init__(self, root):
        self.root = root
        config.ensure_dirs()
        self.cfg = config.Config()
        self.cache = self.cfg["hash_cache"]
        self.game_dir = None
        self.legit = (True, [])
        self.mods = {}
        self._q = queue.Queue()
        self._typing = None
        self.selected_save = None

        root.title("RuneManager - Deltarune Mod Manager")
        root.configure(bg=theme.BG)
        # Windows display scaling (125%, 150%...) makes text bigger, so make the
        # window and layout bigger by the same amount. Never larger than the screen.
        try:
            self.s = max(1.0, float(root.tk.call("tk", "scaling")) / (96 / 72))
        except Exception:
            self.s = 1.0
        theme.SCALE = self.s
        sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
        w = min(int(1180 * self.s), int(sw * 0.94))
        h = min(int(780 * self.s), int(sh * 0.88))
        root.geometry(f"{w}x{h}+{max((sw - w) // 2, 0)}+{max((sh - h) // 3, 0)}")
        root.minsize(min(int(980 * self.s), w), min(int(680 * self.s), h))
        if w < 1180 * self.s or h < 780 * self.s:
            try:
                root.state("zoomed")   # small screen: use all of it
            except tk.TclError:
                pass
        root.protocol("WM_DELETE_WINDOW", self.on_close)

        self.canvas = tk.Canvas(root, bg=theme.BG, highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)
        self.bg = Background(self.canvas)

        # Center panel: black box with a white 2px edge
        self.panel_edge = tk.Frame(self.canvas, bg=theme.FG, padx=2, pady=2)
        self.panel = tk.Frame(self.panel_edge, bg=theme.BG)
        self.panel.pack(fill="both", expand=True)
        self.panel_win = self.canvas.create_window(0, 0, window=self.panel_edge, anchor="n")

        self.tab_names = list(TABS)
        self.tab_items = {}
        self.current = None
        self.tabs = {}
        self.lock_frame = None
        self.canvas.bind("<Configure>", self._layout, add="+")

        self._build_header()
        self._load_tabs()
        self._poll()
        self.root.after(50, self.startup)

    # layout
    def px(self, n):
        return max(1, round(n * self.s))

    def _img(self, item, text, scale, color=None, tracking=1, cache=True):
        img = pf.render(text, self.px(scale), color or theme.FG, theme.SHADOW, tracking, cache)
        self._imgs[item] = img                     # keep a reference (Tk drops unreferenced images)
        self.canvas.itemconfigure(item, image=img)

    def _build_header(self):
        c = self.canvas
        self._imgs = {}
        self.title_id = c.create_image(0, 0, anchor="n")
        self.sub_id = c.create_image(0, 0, anchor="n")
        self.status_bg = c.create_rectangle(0, 0, 0, 0, fill=theme.BG, outline="")
        self.status_id = c.create_image(0, 0, anchor="s")
        self._title_compact = None
        self._img(self.sub_id, "DELTARUNE MOD MANAGER", 1.5, theme.DIM, 2)
        for name in self.tab_names:
            item = c.create_image(0, 0, anchor="n")
            self._img(item, name, 2, theme.DIM, 1)
            c.tag_bind(item, "<Button-1>", lambda e, n=name: self.show_tab(n))
            c.tag_bind(item, "<Enter>", lambda e, n=name: self._tab_hover(n, True))
            c.tag_bind(item, "<Leave>", lambda e, n=name: self._tab_hover(n, False))
            self.tab_items[name] = item

    def _layout(self, e=None):
        """Stack the header from the top using real image sizes, so it fits any
        screen. Short windows get a compact header (smaller title, no subtitle)."""
        c = self.canvas
        w, h = c.winfo_width(), c.winfo_height()
        if w < 10 or h < 10:
            return
        cx = w // 2
        s = self.s
        compact = h < 720 * s
        if self._title_compact != compact:
            self._title_compact = compact
            self._img(self.title_id, "RUNEMANAGER", 3 if compact else 5, theme.FG, 2)
        c.itemconfigure(self.sub_id, state="hidden" if compact else "normal")
        gap = (5 if compact else 9) * s

        def bottom(item):
            box = c.bbox(item)
            return box[3] if box else 0

        y = (10 if compact else 22) * s
        c.coords(self.title_id, cx, y)
        y = bottom(self.title_id) + gap
        if not compact:
            c.coords(self.sub_id, cx, y)
            y = bottom(self.sub_id) + gap
        y += gap
        n = len(self.tab_names)
        spacing = min(150 * s, (w - 120) // n)
        x0 = cx - spacing * (n - 1) / 2
        for i, name in enumerate(self.tab_names):
            c.coords(self.tab_items[name], x0 + i * spacing, y)
        y = y + self.px(2) * 8 + gap * 1.5
        status_h = 34 * s
        pw = min(w - (40 if compact else 140) * s, 1120 * s)
        ph = h - y - status_h
        c.coords(self.panel_win, cx, y)
        c.itemconfigure(self.panel_win, width=int(pw), height=int(max(ph, 200)))
        c.coords(self.status_id, cx, h - 10 * s)
        self._fit_status()
        for item in [self.status_bg, self.title_id, self.sub_id, self.status_id,
                     *self.tab_items.values()]:
            c.tag_raise(item)

    def _fit_status(self):
        box = self.canvas.bbox(self.status_id)
        if box and box[2] - box[0] > 2:
            self.canvas.coords(self.status_bg, box[0] - 12, box[1] - 6, box[2] + 12, box[3] + 5)
        else:
            self.canvas.coords(self.status_bg, 0, 0, 0, 0)

    def _tab_label(self, name, state):
        color = {"on": theme.FG, "hover": theme.FG, "off": theme.DIM}[state]
        text = "> " + name if state == "on" else name
        self._img(self.tab_items[name], text, 2, color, 1)

    def _tab_hover(self, name, on):
        if name != self.current and not self.is_locked():
            self._tab_label(name, "hover" if on else "off")
        self.canvas.config(cursor="hand2" if on else "")

    # tabs
    def _load_tabs(self):
        from .tab_vessel import VesselTab
        from .tab_mods import ModsTab
        from .tab_download import DownloadTab
        from .tab_browse import BrowseTab
        from .tab_saves import SavesTab
        from .tab_secrets import SecretsTab
        from .tab_share import ShareTab
        for name, cls in [("GAME", VesselTab), ("MODS", ModsTab), ("DOWNLOAD", DownloadTab),
                          ("BROWSE", BrowseTab), ("SAVES", SavesTab),
                          ("PRESETS", SecretsTab), ("SHARE", ShareTab)]:
            self.tabs[name] = cls(self.panel, self)

    def show_tab(self, name):
        if self.is_locked() and name != "GAME":
            self.say("Find your game folder first.")
            return
        if self.current:
            self.tabs[self.current].pack_forget()
            self._tab_label(self.current, "off")
        if self.lock_frame:
            self.lock_frame.pack_forget()
        self.current = name
        self._tab_label(name, "on")
        tab = self.tabs[name]
        if tab.requires_game and not self.game_dir:
            tab.pack_forget()
            self._show_placeholder()
        else:
            if getattr(self, "_placeholder", None):
                self._placeholder.pack_forget()
            tab.pack(fill="both", expand=True, padx=22, pady=18)
            tab.on_show()


    def _show_placeholder(self):
        if not getattr(self, "_placeholder", None):
            f = tk.Frame(self.panel, bg=theme.BG)
            theme.label(f, "NO GAME FOLDER SET", 16, theme.FG, True).pack(pady=(120, 10))
            theme.label(f, "Open the Game tab and pick your DELTARUNE folder.",
                        11, theme.DIM).pack()
            theme.GButton(f, "GO TO GAME TAB", lambda: self.show_tab("GAME"), big=True).pack(pady=24)
            self._placeholder = f
        self._placeholder.pack(fill="both", expand=True)

    # game state
    def is_locked(self):
        return bool(self.game_dir) and not self.legit[0]

    def startup(self):
        self._layout()
        gd = self.cfg.get("game_dir")
        if gd and paths.is_game_dir(gd):
            self.set_game_dir(gd, announce=False)
        else:
            found = paths.auto_detect_game()
            if found:
                self.set_game_dir(found, announce=False)
                self.say("Found Deltarune in your Steam library.")
            else:
                self.say("Deltarune not found - press Browse.")
        self.show_tab("GAME")

    def set_game_dir(self, path, announce=True):
        path = paths.resolve_picked_path(path)
        if not paths.is_game_dir(path):
            theme.error(self.root, "Not Deltarune",
                        "That folder doesn't contain DELTARUNE.exe or a data.win.")
            return False
        self.game_dir = Path(path)
        self.cfg["game_dir"] = str(self.game_dir)
        self.cfg.save()
        self.legit = paths.legitimacy_check(self.game_dir)
        self.reload_mods()
        if self.legit[0]:
            self.run_bg(lambda: mods.sync_vanilla(self.game_dir, self.cache),
                        self._after_sync)
            if announce:
                self.say("Game folder set.")
        else:
            self.say("Game folder failed the check.")
        self.refresh_all()
        if self.current:
            self.show_tab(self.current if not self.is_locked() else "GAME")
        return True

    def _after_sync(self, refreshed):
        if refreshed:
            theme.info(self.root, "Game updated",
                       "Steam changed these game files since last time:\n\n  "
                       + "\n  ".join(refreshed)
                       + "\n\nThey're now your new vanilla backup. Mods made for the old "
                         "version are marked in the MODS tab.")
            self.refresh_all()

    def reload_mods(self):
        self.mods = mods.list_mods()
        order = [i for i in self.cfg["load_order"] if i in self.mods]
        order += [i for i in sorted(self.mods) if i not in order]
        self.cfg["load_order"] = mods.sort_by_requirements(order, self.mods)
        self.cfg["enabled"] = [i for i in self.cfg["enabled"] if i in self.mods]
        self.cfg.save()

    def refresh_all(self):
        for t in self.tabs.values():
            try:
                t.refresh()
            except Exception:
                traceback.print_exc()

    # background runner
    def run_bg(self, work, done=None, fail=None):
        """Run work() on a thread. done(result)/fail(exc) are called back on the UI thread."""
        def worker():
            try:
                self._q.put(("ok", done, work()))
            except Exception as exc:
                traceback.print_exc()
                self._q.put(("err", fail, exc))
        threading.Thread(target=worker, daemon=True).start()

    def call_ui(self, fn, *args):
        self._q.put(("call", fn, args))

    def _poll(self):
        while True:
            try:
                kind, cb, val = self._q.get_nowait()
            except queue.Empty:
                break
            try:
                if kind == "call":
                    cb(*val)
                elif kind == "ok" and cb:
                    cb(val)
                elif kind == "err":
                    if cb:
                        cb(val)
                    else:
                        theme.error(self.root, "Something went wrong", str(val))
            except tk.TclError:
                pass          # a tab was rebuilt or the window closed mid-task
            except Exception:
                traceback.print_exc()
        self.root.after(60, self._poll)

    # status
    def say(self, text):
        """One line of status at the bottom of the window."""
        self._img(self.status_id, str(text), 1.5, theme.DIM, 1, cache=False)
        self._fit_status()

    def on_close(self):
        self.bg.running = False
        self.cfg.save()
        self.root.destroy()


class Tab(tk.Frame):
    """Base class for each screen."""
    requires_game = True

    def __init__(self, parent, app):
        super().__init__(parent, bg=theme.BG)
        self.app = app
        self.build()

    def build(self):
        pass

    def refresh(self):
        pass

    def on_show(self):
        self.refresh()

    def heading(self, parent, text, sub=""):
        theme.label(parent, text, 14, theme.FG, True).pack(anchor="w")
        if sub:
            sub_lbl = theme.label(parent, sub, 9, theme.DIM)
            sub_lbl.pack(anchor="w", pady=(2, 0), fill="x")
            sub_lbl.bind("<Configure>", lambda e: sub_lbl.config(wraplength=max(e.width - 4, 100)))
        theme.rule(parent).pack(fill="x", pady=(8, 12))
