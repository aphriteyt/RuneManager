"""BROWSE tab - GameBanana."""
import threading
import tkinter as tk
import webbrowser

from core import backup, gamebanana, mods, paths
from . import theme
from .app import Tab

SORT_ORDER = ["UPDATED", "NEWEST", "POPULAR", "LIKED"]


class BrowseTab(Tab):
    requires_game = False       # browsing is fine before the game is found

    def build(self):
        self.page = 1
        self.pages = 1
        self.query = ""
        self.sort = "UPDATED"
        self.records = []
        self.busy = set()
        self.loading = False
        self.status_labels = {}

        self.heading(self, "BROWSE GAMEBANANA", "Downloads come straight from each mod's own page.")

        bar = tk.Frame(self, bg=theme.BG)
        bar.pack(fill="x", pady=(0, 6))
        theme.label(bar, "SEARCH", 9, theme.DIM).pack(side="left", padx=(0, 6))
        self.sort_btn = theme.Dropdown(bar, SORT_ORDER, self.pick_sort, width=10)
        self.sort_btn.pack(side="right")
        theme.label(bar, "SORT", 9, theme.DIM).pack(side="right", padx=(12, 6))
        theme.GButton(bar, "LATEST", self.clear_search).pack(side="right")
        theme.GButton(bar, "SEARCH", self.do_search).pack(side="right")
        self.entry = theme.entry(bar, 24)
        self.entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.entry.bind("<Return>", lambda e: self.do_search())

        pager = tk.Frame(self, bg=theme.BG)
        pager.pack(side="bottom", fill="x", pady=(8, 0))
        self.prev_btn = theme.GButton(pager, "< PREV PAGE", self.prev_page)
        self.prev_btn.pack(side="left")
        self.next_btn = theme.GButton(pager, "NEXT PAGE >", self.next_page)
        self.next_btn.pack(side="left")
        self.page_lbl = theme.label(pager, "", 9, theme.DIM)
        self.page_lbl.pack(side="left", padx=14)
        theme.GButton(pager, "OPEN GAMEBANANA",
                      lambda: webbrowser.open("https://gamebanana.com/games/6755")
                      ).pack(side="right")

        self.list = theme.ScrollFrame(self)
        self.list.pack(fill="both", expand=True)
        self.loaded_once = False

    # loading
    def on_show(self):
        if not self.loaded_once:
            self.loaded_once = True
            self.load()

    def refresh(self):
        pass                     # the list only changes when the user asks

    def load(self):
        if self.loading:
            return
        self.loading = True
        self._message("REACHING GAMEBANANA...")
        page, query, sort = self.page, self.query, self.sort

        def work():
            if query:
                return gamebanana.search(query, page)
            return gamebanana.browse(page, sort)

        def done(result):
            self.loading = False
            if (page, query, sort) != (self.page, self.query, self.sort):
                return                     # the user moved on while we waited
            self.records, self.pages = result
            self.draw()

        def fail(exc):
            self.loading = False
            self._message(str(exc), theme.RED)
            self.app.say("GameBanana did not respond.")
        self.app.run_bg(work, done, fail)

    def _message(self, text, color=theme.DIM):
        for w in self.list.inner.winfo_children():
            w.destroy()
        theme.label(self.list.inner, "\n  " + text, 11, color,
                    wraplength=int(700 * self.app.s)).pack(anchor="w")
        self.page_lbl.config(text="")

    # drawing
    def draw(self):
        for w in self.list.inner.winfo_children():
            w.destroy()
        self.status_labels = {}
        if not self.records:
            self._message("NOTHING FOUND." if self.query else "NO MODS CAME BACK.")
            return
        for r in self.records:
            self._card(r)
        self.list.to_top()
        self.page_lbl.config(text=f"PAGE {self.page} OF {self.pages}")
        self.prev_btn.set_enabled(self.page > 1)
        self.next_btn.set_enabled(self.page < self.pages)

    def _card(self, r):
        edge = tk.Frame(self.list.inner, bg=theme.FAINT, padx=1, pady=1)
        edge.pack(fill="x", pady=4, padx=(0, 14))
        card = tk.Frame(edge, bg=theme.BG, padx=12, pady=8)
        card.pack(fill="x")

        mid = tk.Frame(card, bg=theme.BG)
        mid.pack(side="left", fill="x", expand=True)
        theme.label(mid, r["name"][:60], 11, theme.FG, True).pack(anchor="w")
        bits = [f"by {r['author']}"]
        if r["category"]:
            bits.append(r["category"])
        bits.append(r["updated"])
        if r["views"]:
            bits.append(f"{r['views']:,} views")
        theme.label(mid, "  |  ".join(bits), 9, theme.DIM,
                    wraplength=int(620 * self.app.s)).pack(anchor="w")
        status = theme.label(mid, "", 9, theme.GOLD)
        status.pack(anchor="w")
        self.status_labels[r["id"]] = status

        side = tk.Frame(card, bg=theme.BG)
        side.pack(side="right", anchor="n")
        theme.GButton(side, "PAGE", lambda: webbrowser.open(r["url"])).pack(side="left", padx=(8, 0))
        btn = theme.GButton(side, "INSTALL", lambda: self.install(r), big=True)
        btn.set_enabled(r["has_files"] and r["id"] not in self.busy)
        btn.pack(side="left")
        if not r["has_files"]:
            status.config(text="No downloadable files on this mod.", fg=theme.DIM)

    def _set_status(self, mod_id, text, color=theme.GOLD):
        lbl = self.status_labels.get(mod_id)
        if lbl and lbl.winfo_exists():
            lbl.config(text=text, fg=color)

    # paging
    def do_search(self):
        self.query = self.entry.get().strip()
        self.page = 1
        self.load()

    def clear_search(self):
        self.entry.delete(0, "end")
        self.query = ""
        self.page = 1
        self.load()

    def pick_sort(self, value):
        self.sort = value
        self.page = 1
        if not self.query:
            self.load()

    def prev_page(self):
        if self.page > 1:
            self.page -= 1
            self.load()

    def next_page(self):
        if self.page < self.pages:
            self.page += 1
            self.load()

    # installing
    def install(self, r):
        """Fetch the mod's file list, let the user pick, then download + install."""
        if r["id"] in self.busy:
            return
        if not self.app.game_dir:
            theme.error(self.app.root, "No game yet",
                        "Set your DELTARUNE folder on the Game tab first - "
                        "RuneManager needs it to check a mod fits your version.")
            return
        self.busy.add(r["id"])
        self._set_status(r["id"], "LOOKING AT ITS FILES...")

        def work():
            return gamebanana.files(r["id"]), gamebanana.requirements(r["id"])

        def got(result):
            file_list, reqs = result
            self.busy.discard(r["id"])
            chosen = self._choose_file(r, file_list)
            if not chosen:
                self._set_status(r["id"], "")
                return
            extras = self._handle_requirements(r, reqs)
            if extras is None:
                self._set_status(r["id"], "")
                return
            self._download(r, chosen, extras, reqs)

        def fail(exc):
            self.busy.discard(r["id"])
            self._set_status(r["id"], str(exc), theme.RED)
        self.app.run_bg(work, got, fail)

    def _install_dependency(self, req, app):
        """Download and import one required mod. Runs on the worker thread."""
        import shutil
        if req["kind"] == "gamebanana":
            info = gamebanana.mod_info(req["ref"])
            pick = gamebanana.best_file(gamebanana.files(req["ref"]))
            if pick is None:
                raise gamebanana.GBError(
                    f"{req['name']} has no file RuneManager can install. "
                    f"Get it yourself from {req['url']}")
            path = gamebanana.download(pick)
            try:
                mod, _ = mods.import_mod(path, app.game_dir, source_url=info["url"],
                                         source_version=pick.get("version", ""),
                                         name_hint=info["name"], cache=app.cache,
                                         mod_id=info["name"],
                                         description=f"From GameBanana, by {info['author']}.")
            finally:
                shutil.rmtree(path.parent, ignore_errors=True)
        else:
            from core import downloader
            path, version = downloader.download(req["ref"])
            try:
                mod, _ = mods.import_mod(path, app.game_dir, source_url=req["ref"],
                                         source_version=version, name_hint=req["name"],
                                         cache=app.cache, mod_id=req["name"],
                                         description="Required by another mod.")
            finally:
                shutil.rmtree(path.parent, ignore_errors=True)
        app.call_ui(self._enable_mod, mod.id)
        return mod

    def _enable_mod(self, mod_id):
        self.app.reload_mods()
        if mod_id not in self.app.cfg["enabled"]:
            self.app.cfg["enabled"].append(mod_id)
            self.app.cfg.save()

    def _choose_file(self, r, file_list):
        """One file: take it. Several: ask. Returns the file dict or None."""
        pick = gamebanana.best_file(file_list)
        if len(file_list) > 1:
            options = []
            for f in file_list:
                size = f"{f['size'] / 1048576:.1f} MB" if f["size"] else "?"
                flag = "" if f["clean"] else "  [FAILED VIRUS SCAN]"
                ver = f" v{f['version']}" if f["version"] else ""
                options.append(f"{f['name'][:40]:<40} {size:>9}{ver}{flag}")
            start = file_list.index(pick) if pick in file_list else 0
            i = theme.choose(self.app.root, "Which file?",
                             f"{r['name']} has {len(file_list)} downloads. Pick the one "
                             "for the PC version of the game.\n"
                             f"(Best guess: {pick['name'] if pick else 'none'})",
                             options, ok="DOWNLOAD", width=72)
            if i is None:
                return None
            pick = file_list[i]
        if not pick:
            theme.error(self.app.root, "Nothing installable",
                        "None of this mod's files look like something RuneManager can "
                        "install. Press PAGE to see it on GameBanana.")
            return None
        if not pick["clean"]:
            if not theme.confirm(self.app.root, "Virus scan failed",
                                 f"GameBanana's scanner flagged {pick['name']}.\n\n"
                                 "Download it anyway?", yes="DOWNLOAD", no="NO",
                                 danger=True):
                return None
        return pick

    def _handle_requirements(self, r, reqs):
        """Work out which other mods this one needs. Returns the list to install
        first, or None if the user backed out."""
        missing = []
        for req in reqs:
            if req["kind"] == "gamebanana" and self._installed_from(req["url"]):
                continue
            if req["kind"] == "github" and self._installed_from(req["ref"]):
                continue
            missing.append(req)
        if not missing:
            return []
        auto = [q for q in missing if q["kind"] in ("gamebanana", "github")]
        manual = [q for q in missing if q["kind"] == "other"]
        lines = []
        if auto:
            lines.append("RuneManager can install these for you:")
            lines += [f"  - {q['name']}  ({q['level']})" for q in auto]
        if manual:
            if lines:
                lines.append("")
            lines.append("These you'd have to get yourself:")
            lines += [f"  - {q['name']}" + (f"  {q['url']}" if q["url"] else "") for q in manual]
        body = f"{r['name']} says it needs other things first.\n\n" + "\n".join(lines)

        if auto:
            buttons = ("INSTALL ALL", "JUST THIS MOD", "CANCEL")
        else:
            buttons = ("CONTINUE", "OPEN THEIR PAGES", "CANCEL")
        choice = theme.ask(self.app.root, "This mod needs others", body, buttons)
        if choice in (None, "CANCEL"):
            return None
        if choice == "OPEN THEIR PAGES":
            for q in manual:
                if q["url"]:
                    webbrowser.open(q["url"])
            return []
        if manual and choice == "INSTALL ALL":
            for q in manual:
                if q["url"]:
                    webbrowser.open(q["url"])
        return auto if choice == "INSTALL ALL" else []

    def _installed_from(self, url_or_ref):
        key = (url_or_ref or "").strip().lower().rstrip("/")
        if not key:
            return False
        for m in self.app.mods.values():
            src = (m.source_url or "").strip().lower().rstrip("/")
            if src and (src == key or (key in src) or (src in key)):
                return True
        return False

    def _download(self, r, file_entry, extras=(), reqs=()):
        app = self.app
        self.busy.add(r["id"])
        cancel = threading.Event()
        self.app.say("Downloading...")

        def progress(done, total):
            text = (f"DOWNLOADING {done * 100 // total:3d}%  "
                    f"({done / 1048576:.1f} / {total / 1048576:.1f} MB)" if total
                    else f"DOWNLOADING {done / 1048576:.1f} MB")
            app.call_ui(self._set_status, r["id"], text, theme.FG)

        def work():
            import shutil
            backup.snapshot_saves("before-download")
            for q in extras:                     # required mods come first
                app.call_ui(self._set_status, r["id"], f"INSTALLING {q['name'][:28]}...", theme.FG)
                self._install_dependency(q, app)
            if extras:
                app.call_ui(self._set_status, r["id"], "DOWNLOADING...", theme.FG)
            path = gamebanana.download(file_entry, progress, cancel)
            app.call_ui(self._set_status, r["id"], "UNPACKING...", theme.FG)
            try:
                return mods.import_mod(
                    path, app.game_dir, source_url=r["url"],
                    source_version=file_entry.get("version", ""),
                    name_hint=r["name"], cache=app.cache, mod_id=r["name"],
                    description=f"From GameBanana, by {r['author']}.",
                    requires=[q for q in reqs if q["kind"] in ("gamebanana", "github")])
            finally:
                shutil.rmtree(path.parent, ignore_errors=True)

        def done(result):
            self.busy.discard(r["id"])
            mod, notes = result
            app.reload_mods()
            if mod.id not in app.cfg["enabled"]:
                app.cfg["enabled"].append(mod.id)
                app.cfg.save()
            app.refresh_all()
            errors, _ = mods.check_mod(mod, app.game_dir, app.cfg, app.cache)
            if errors:
                self._set_status(r["id"], "INSTALLED - but " + errors[0], theme.RED)
            else:
                self._set_status(r["id"], "INSTALLED.  APPLY IT IN THE MODS TAB.", theme.FG)
            app.say(f"Installed {mod.name}.")
            loud = [n for n in notes if not n.startswith("Skipped")]
            if loud:
                theme.info(app.root, "Installed", "\n".join(loud))

        def fail(exc):
            self.busy.discard(r["id"])
            self._set_status(r["id"], str(exc).split("\n")[0], theme.RED)
            theme.error(app.root, "Couldn't install that one", str(exc))
        app.run_bg(work, done, fail)
