"""The backdrop. Dark navy with a soft vertical fade and a little grain."""
import random
import tkinter as tk

from core import config

BLOCK = 3
TOP = (8, 8, 17)
BOTTOM = (16, 15, 30)
GRAIN = 4
CUSTOM_BG = config.DATA_DIR / "background.png"


class Background:
    def __init__(self, canvas, motion=False):
        self.c = canvas
        self.running = True
        self.title_ids = []
        self.item = canvas.create_image(0, 0, anchor="center", tags="bg")
        self.w = self.h = 0
        self.shown = None
        self.custom = None
        canvas.bind("<Configure>", self._on_resize, add="+")
        self.reload_custom()

    def reload_custom(self):
        self.custom = None
        if CUSTOM_BG.exists():
            try:
                self.custom = tk.PhotoImage(file=str(CUSTOM_BG))
            except tk.TclError:
                self.custom = None
        self.w = self.h = 0
        self._on_resize(None)

    def _show_custom(self):
        img = self.custom
        iw, ih = img.width(), img.height()
        need = max(self.w / iw, self.h / ih)
        best = (99, 1, 1)
        for z in range(1, 5):
            for sub in range(1, 6):
                if need <= z / sub < best[0]:
                    best = (z / sub, z, sub)
        _, z, sub = best
        scaled = img.zoom(z) if z > 1 else img
        if sub > 1:
            scaled = scaled.subsample(sub)
        self.shown = scaled
        self.c.itemconfigure(self.item, image=scaled)

    def _draw(self):
        gw = max(2, -(-self.w // BLOCK))
        gh = max(2, -(-self.h // BLOCK))
        rnd = random.Random(4)
        rows = []
        for y in range(gh):
            f = y / (gh - 1)
            base = [TOP[i] + (BOTTOM[i] - TOP[i]) * f for i in range(3)]
            flat = "#%02x%02x%02x" % tuple(int(c) for c in base)
            row = []
            for _ in range(gw):
                if rnd.random() < 0.12:      # a few specks, not static
                    n = rnd.randint(1, GRAIN)
                    row.append("#%02x%02x%02x" % tuple(
                        max(0, min(255, int(c + n))) for c in base))
                else:
                    row.append(flat)
            rows.append(" ".join(row))
        img = tk.PhotoImage(width=gw, height=gh)
        img.put(" ".join("{" + r + "}" for r in rows))
        self.shown = img.zoom(BLOCK)
        self.c.itemconfigure(self.item, image=self.shown)

    def _on_resize(self, e):
        w = self.c.winfo_width() if e is None else e.width
        h = self.c.winfo_height() if e is None else e.height
        if w < 10 or h < 10:
            return
        if abs(w - self.w) < BLOCK * 2 and abs(h - self.h) < BLOCK * 2 and self.shown:
            self.c.coords(self.item, w // 2, h // 2)
            return
        self.w, self.h = w, h
        self.c.coords(self.item, w // 2, h // 2)
        if self.custom is not None:
            self._show_custom()
        else:
            self._draw()
        self.c.tag_lower("bg")

    def set_motion(self, on):
        pass

    def build(self):
        self.w = self.h = 0
        self._on_resize(None)
