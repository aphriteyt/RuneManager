"""SHARE tab - GONER- codes."""
import tkinter as tk

from core import share
from . import theme
from .app import Tab


class ShareTab(Tab):
    def build(self):
        cols = tk.Frame(self, bg=theme.BG)
        cols.pack(fill="both", expand=True)
        right = tk.Frame(cols, bg=theme.BG)
        right.pack(side="right", fill="both", expand=True)
        left = tk.Frame(cols, bg=theme.BG)
        left.pack(side="left", fill="both", expand=True, padx=(0, 24))

        self.heading(left, "SHARE YOUR LOADOUT", "Enabled mods, versions and order.")
        self.mine = theme.textbox(left, height=5)
        self.mine.pack(fill="x")
        row = tk.Frame(left, bg=theme.BG)
        row.pack(anchor="w", pady=10)
        theme.GButton(row, "GENERATE CODE", self.generate).pack(side="left", padx=(0, 8))
        theme.GButton(row, "COPY", self.copy).pack(side="left")
        self.mine_info = theme.label(left, "", 9, theme.DIM, wraplength=480)
        self.mine_info.pack(anchor="w")

        self.heading(right, "LOAD A CODE", "Paste a code from someone else.")
        self.theirs = theme.textbox(right, height=5)
        self.theirs.pack(fill="x")
        row2 = tk.Frame(right, bg=theme.BG)
        row2.pack(anchor="w", pady=10)
        theme.GButton(row2, "PASTE", self.paste).pack(side="left", padx=(0, 8))
        self.load_btn = theme.GButton(row2, "LOAD CODE", self.load, big=True)
        self.load_btn.pack(side="left")
        self.report = theme.textbox(right, height=10)
        self.report.pack(fill="both", expand=True)

    def _enabled_mods(self):
        app = self.app
        return [app.mods[i] for i in app.cfg["load_order"] if i in app.cfg["enabled"] and i in app.mods]

    def refresh(self):
        ms = self._enabled_mods()
        no_link = [m.name for m in ms if not m.source_url]
        text = f"{len(ms)} mod(s) enabled."
        if no_link:
            text += (" These were imported from files, so friends need them already installed: "
                     + ", ".join(no_link) + ". (Mods from DOWNLOAD buttons carry their link.)")
        self.mine_info.config(text=text, fg=theme.GOLD if no_link else theme.DIM)

    def generate(self):
        ms = self._enabled_mods()
        if not ms:
            theme.info(self.app.root, "Nothing to share", "Enable some mods first.")
            return
        self.mine.delete("1.0", "end")
        self.mine.insert("1.0", share.encode(ms))
        self.app.say("Code generated.")

    def copy(self):
        code = self.mine.get("1.0", "end").strip()
        if not code:
            self.generate()
            code = self.mine.get("1.0", "end").strip()
        if code:
            self.app.root.clipboard_clear()
            self.app.root.clipboard_append(code)
            self.app.say("Copied to clipboard.")

    def paste(self):
        try:
            text = self.app.root.clipboard_get()
        except Exception:
            return
        self.theirs.delete("1.0", "end")
        self.theirs.insert("1.0", text)

    def _log(self, text):
        self.report.insert("end", text + "\n")
        self.report.see("end")

    def load(self):
        try:
            wanted = share.decode(self.theirs.get("1.0", "end"))
        except ValueError as exc:
            theme.error(self.app.root, "Bad code", str(exc))
            return
        self.report.delete("1.0", "end")
        self.load_btn.set_enabled(False)
        self._log(f"Code holds {len(wanted)} mod(s).")
        self._process(wanted, 0, [])

    def _process(self, wanted, i, missing):
        """Walk the list one by one, downloading anything not installed."""
        app = self.app
        if i >= len(wanted):
            return self._finish(wanted, missing)
        w = wanted[i]
        have = app.mods.get(w["id"])
        if have and (have.version == w["version"] or not w["url"]):
            self._log(f"  have     {w['name']}")
            return self._process(wanted, i + 1, missing)
        if not w["url"]:
            self._log(f"  MISSING  {w['name']} (no download link in the code)")
            return self._process(wanted, i + 1, missing + [w["name"]])
        self._log(f"  fetching {w['name']}...")

        def ok(mod):
            if mod.id != w["id"]:
                w["id"] = mod.id
            self._log(f"  got      {mod.name}")
            self._process(wanted, i + 1, missing)

        def bad(exc):
            self._log(f"  FAILED   {w['name']}: {exc}")
            self._process(wanted, i + 1, missing + [w["name"]])
        app.tabs["DOWNLOAD"].fetch(w["url"], w["name"], ok, bad, enable=False)

    def _finish(self, wanted, missing):
        app = self.app
        app.reload_mods()
        ids = [w["id"] for w in wanted if w["id"] in app.mods]
        rest = [i for i in app.cfg["load_order"] if i not in ids]
        app.cfg["load_order"] = ids + rest
        app.cfg["enabled"] = ids
        app.cfg.save()
        app.refresh_all()
        self.load_btn.set_enabled(True)
        self._log(f"Enabled {len(ids)} mod(s) in the shared order.")
        if missing:
            self._log("Missing: " + ", ".join(missing))
        if theme.confirm(app.root, "Loadout ready",
                         f"{len(ids)} mod(s) are enabled in the shared order."
                         + (f"\n\nCouldn't get: {', '.join(missing)}" if missing else "")
                         + "\n\nApply them to the game now?", yes="APPLY", no="LATER"):
            app.show_tab("MODS")
            app.tabs["MODS"].apply()
