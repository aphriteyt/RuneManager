"""DOWNLOAD tab - the one-click buttons."""
import shutil
import threading
import tkinter as tk

from core import backup, config, downloader, mods, paths
from . import theme
from .app import Tab


class DownloadTab(Tab):
    def build(self):
        top = tk.Frame(self, bg=theme.BG)
        top.pack(fill="x")
        hd = tk.Frame(top, bg=theme.BG)
        hd.pack(side="left", fill="x", expand=True)
        self.heading(hd, "DOWNLOAD MODS", "One-click installs from each mod's own GitHub release.")
        btns = tk.Frame(top, bg=theme.BG)
        btns.pack(side="right", anchor="n", before=hd)
        theme.GButton(btns, "FIND MORE MODS", self.find_more).pack(side="left")
        theme.GButton(btns, "+ ADD", self.add_entry).pack(side="left")
        theme.GButton(btns, "CHECK FOR UPDATES", self.check_updates).pack(side="left")
        self.grid_area = theme.ScrollFrame(self)
        self.grid_area.pack(fill="both", expand=True)
        self.status = {}        # url -> label widget
        self.updates = {}       # url -> latest tag
        self.busy = set()

    def catalog(self):
        return config.read_json(config.CATALOG_FILE, [])

    def save_catalog(self, cat):
        config.write_json(config.CATALOG_FILE, cat)

    @staticmethod
    def _key(url):
        return (url or "").strip().lower().replace("https://github.com/", "github:").rstrip("/")

    def installed_for(self, url):
        for m in self.app.mods.values():
            if url and self._key(m.source_url) == self._key(url):
                return m
        return None

    # drawing
    def refresh(self):
        inner = self.grid_area.inner
        for w in inner.winfo_children():
            w.destroy()
        self.status = {}
        cat = self.catalog()
        cols = 2
        for c in range(cols):
            inner.grid_columnconfigure(c, weight=1, uniform="cards")
        for i, entry in enumerate(cat):
            self._card(inner, i, entry).grid(row=i // cols, column=i % cols, sticky="nsew",
                                             padx=(0, 14), pady=7)
        if not cat:
            theme.label(inner, "\n  NO DOWNLOAD BUTTONS.  PRESS + ADD DOWNLOAD BUTTON.",
                        11, theme.DIM).grid(row=0, column=0, sticky="w")

    def _card(self, parent, index, e):
        url = e.get("url", "")
        edge = tk.Frame(parent, bg=theme.FAINT, padx=1, pady=1)
        card = tk.Frame(edge, bg=theme.BG, padx=14, pady=10)
        card.pack(fill="both", expand=True)
        head = tk.Frame(card, bg=theme.BG)
        head.pack(fill="x")
        theme.label(head, e.get("name", "?").upper(), 12, theme.FG, True).pack(side="left", anchor="w")
        if e.get("category"):
            theme.label(head, e["category"], 8, theme.DIM).pack(side="right", anchor="ne")
        theme.label(card, f"by {e.get('author', '?')}", 9, theme.DIM).pack(anchor="w")
        theme.label(card, e.get("description", ""), 9, theme.FG,
                    wraplength=int(430 * self.app.s)).pack(anchor="w", pady=(4, 2))
        theme.label(card, url or "(no link yet - press EDIT)", 8,
                    theme.FAINT if url else theme.GOLD,
                    wraplength=int(430 * self.app.s)).pack(anchor="w")
        st = theme.label(card, "", 9, theme.DIM)
        mod = self.installed_for(url)
        if mod:
            st.config(text=f"INSTALLED  v{mod.manifest.get('source_version') or mod.version}",
                      fg=theme.FG)
        if url in self.updates:
            st.config(text=f"UPDATE AVAILABLE: {self.updates[url]}", fg=theme.GOLD)
        st.pack(anchor="w", pady=(4, 6))
        self.status[url] = st
        row = tk.Frame(card, bg=theme.BG)
        row.pack(anchor="w")
        label = "UPDATE" if url in self.updates else ("REINSTALL" if mod else "DOWNLOAD")
        b = theme.GButton(row, label, lambda: self.fetch_entry(e))
        b.set_enabled(bool(url) and url not in self.busy)
        b.pack(side="left", padx=(0, 6))
        theme.GButton(row, "EDIT", lambda: self.edit_entry(index)).pack(side="left", padx=(0, 6))
        theme.GButton(row, "X", lambda: self.delete_entry(index), danger=True).pack(side="left")
        return edge

    # catalog edits
    def _entry_dialog(self, title, e):
        res, vals = theme.ask(self.app.root, title,
                              "Link can be: github:owner/repo  (newest release), a GitHub repo "
                              "URL, or any direct link to a .zip / .xdelta / data.win / .dll.",
                              ("SAVE", "CANCEL"),
                              fields={"name": ("NAME", e.get("name", "")),
                                      "author": ("AUTHOR", e.get("author", "")),
                                      "description": ("DESCRIPTION", e.get("description", "")),
                                      "url": ("DOWNLOAD LINK", e.get("url", "")),
                                      "asset": ("FILE TO PICK (optional, e.g. windows)",
                                                e.get("asset", ""))})
        if res != "SAVE" or not vals["name"].strip():
            return None
        return {k: v.strip() for k, v in vals.items()}

    def add_entry(self):
        e = self._entry_dialog("Add download button", {})
        if e:
            cat = self.catalog()
            cat.append(e)
            self.save_catalog(cat)
            self.refresh()

    def edit_entry(self, index):
        cat = self.catalog()
        e = self._entry_dialog("Edit download button", cat[index])
        if e:
            cat[index] = {**cat[index], **e}      # keep category and other extras
            self.save_catalog(cat)
            self.refresh()

    def delete_entry(self, index):
        cat = self.catalog()
        if theme.confirm(self.app.root, "Remove button",
                         f"Remove the {cat[index].get('name')} button? "
                         "(An installed mod stays installed.)", danger=True):
            cat.pop(index)
            self.save_catalog(cat)
            self.refresh()

    # downloading
    def fetch_entry(self, e):
        self.fetch(e["url"], e.get("name", ""), asset=e.get("asset", ""))

    def fetch(self, url, name="", done_cb=None, fail_cb=None, enable=True, asset=""):
        """Download + install a mod from a link, in the background."""
        if url in self.busy:
            return
        self.busy.add(url)
        self._set_status(url, "CONTACTING...", theme.DIM)
        self.app.say("Downloading...")
        app = self.app
        cancel = threading.Event()

        def progress(done, total):
            text = (f"DOWNLOADING  {done * 100 // total:3d}%  ({done / 1048576:.1f} MB)"
                    if total else f"DOWNLOADING  {done / 1048576:.1f} MB")
            app.call_ui(self._set_status, url, text, theme.FG)

        def work():
            backup.snapshot_saves("before-download")
            path, version = downloader.download(url, progress, cancel, pattern=asset)
            app.call_ui(self._set_status, url, "UNPACKING...", theme.FG)
            try:
                entry = next((e for e in self.catalog()
                              if self._key(e.get("url", "")) == self._key(url)), {})
                return mods.import_mod(path, app.game_dir, source_url=url,
                                       source_version=version, name_hint=name,
                                       cache=app.cache, mod_id=name or None,
                                       description=entry.get("description", ""))
            finally:
                shutil.rmtree(path.parent, ignore_errors=True)   # drop the downloaded zip

        def done(result):
            self.busy.discard(url)
            self.updates.pop(url, None)
            mod, notes = result
            app.reload_mods()
            if enable and mod.id not in app.cfg["enabled"]:
                app.cfg["enabled"].append(mod.id)
                app.cfg.save()
            app.refresh_all()
            app.say(f"Installed {mod.name} - apply it in the Mods tab.")
            if notes and not done_cb:
                theme.info(app.root, "Installed", "\n".join(notes))
            if done_cb:
                done_cb(mod)

        def fail(exc):
            self.busy.discard(url)
            self._set_status(url, "FAILED", theme.RED)
            if fail_cb:
                fail_cb(exc)
            else:
                theme.error(app.root, "Download failed", str(exc))
            self.refresh()
        self.refresh()
        app.run_bg(work, done, fail)

    def _set_status(self, url, text, color):
        lbl = self.status.get(url)
        if lbl and lbl.winfo_exists():
            lbl.config(text=text, fg=color)

    # searching
    def find_more(self):
        """Search GitHub for Deltarune mods and offer the ones that can be installed."""
        self.app.say("Searching GitHub...")
        known = {self._key(e.get("url", "")) for e in self.catalog()}

        def work():
            found = downloader.search_github("deltarune")
            out = []
            for r in found:
                if self._key("github:" + r["repo"]) in known:
                    continue
                ok, info = downloader.check_repo(r["repo"])     # must have a usable release
                if ok:
                    r["release"] = info
                    out.append(r)
                if len(out) >= 12:
                    break
            return out

        def done(results):
            if not results:
                theme.info(self.app.root, "Nothing new",
                           "No new Deltarune mods with installable downloads were found on "
                           "GitHub.\n\nMost mods live on GameBanana or Nexus Mods instead - "
                           "download those yourself and use IMPORT MOD FILE in the MODS tab.")
                return
            options = [f"{r['name'][:28]:<28} by {r['author'][:14]:<14} "
                       f"{('*' + str(r['stars'])):>6}  {r['release'][:28]}" for r in results]
            i = theme.choose(self.app.root, "Mods found on GitHub",
                             "These repos have a download RuneManager can install. They are "
                             "NOT checked for your game version - that happens when you "
                             "install one.", options, ok="ADD BUTTON", width=84)
            if i is None:
                return
            r = results[i]
            cat = self.catalog()
            cat.append({"name": r["name"].title(), "author": r["author"],
                        "description": r["description"] or "From GitHub.",
                        "url": "github:" + r["repo"]})
            self.save_catalog(cat)
            self.refresh()
            self.app.say(f"Added a button for {r['name']}.")

        def fail(exc):
            theme.error(self.app.root, "Search failed", str(exc))
        self.app.run_bg(work, done, fail)

    def check_updates(self):
        cat = [e for e in self.catalog() if e.get("url")]
        self.app.say("Checking for updates...")

        def work():
            found = {}
            for e in cat:
                tag = downloader.latest_version(e["url"], e.get("asset", ""))
                mod = self.installed_for(e["url"])
                if tag and mod and mod.manifest.get("source_version") != tag:
                    found[e["url"]] = tag
            return found

        def done(found):
            self.updates = found
            self.refresh()
            self.app.say(f"{len(found)} update(s) available." if found else "Everything is up to date.")
        self.app.run_bg(work, done)
