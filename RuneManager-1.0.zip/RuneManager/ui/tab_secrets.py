"""PRESETS tab - record save values, write them back later."""
import json
import tkinter as tk
from tkinter import filedialog

from core import config, paths, saves
from . import theme
from .app import Tab

SNAP_FILE = config.DATA_DIR / "recorder_snapshot.json"


class SecretsTab(Tab):
    def build(self):
        top = tk.Frame(self, bg=theme.BG)
        top.pack(fill="x")
        hd = tk.Frame(top, bg=theme.BG)
        hd.pack(side="left", fill="x", expand=True)
        self.heading(hd, "SAVE PRESETS",
                     "Write a recorded set of save values back into any save file.")
        r = tk.Frame(top, bg=theme.BG)
        r.pack(side="right", anchor="n", before=hd)
        theme.label(r, "TARGET SAVE", 9, theme.DIM).pack(side="left", padx=6)
        self.picker = theme.Dropdown(r, [], lambda v: None, width=16)
        self.picker.pack(side="left")

        body = tk.Frame(self, bg=theme.BG)
        body.pack(fill="both", expand=True)
        side = tk.Frame(body, bg=theme.BG, width=int(340 * self.app.s))
        side.pack(side="right", fill="y")
        side.pack_propagate(False)
        left = tk.Frame(body, bg=theme.BG)
        left.pack(side="left", fill="both", expand=True, padx=(0, 18))
        row = tk.Frame(left, bg=theme.BG)
        row.pack(side="bottom", anchor="w", pady=(8, 0))
        theme.GButton(row, "IMPORT PRESETS", self.import_presets).pack(side="left", padx=(0, 6))
        theme.GButton(row, "EXPORT PRESETS", self.export_presets).pack(side="left")
        self.cards = theme.ScrollFrame(left)
        self.cards.pack(fill="both", expand=True)


        theme.label(side, "RECORDER", 12, theme.FG, True).pack(anchor="w")
        theme.rule(side).pack(fill="x", pady=6)
        row = tk.Frame(side, bg=theme.BG)
        row.pack(anchor="w", pady=(0, 6))
        theme.GButton(row, "TAKE SNAPSHOT", self.take_snapshot).pack(side="left", padx=(0, 6))
        theme.GButton(row, "COMPARE", self.compare).pack(side="left")
        self.snap_lbl = theme.label(side, "", 9, theme.GOLD, wraplength=int(320 * self.app.s))
        self.snap_lbl.pack(anchor="w", pady=(0, 8))
        steps = ("1. Choose the TARGET SAVE above.\n"
                 "2. Press TAKE SNAPSHOT.\n"
                 "3. Play: trigger the secret / encounter / easter egg, then SAVE in-game "
                 "and close DELTARUNE.\n"
                 "4. Press COMPARE, tick the lines that matter, name it.\n\n"
                 "That preset becomes a button. Press it on any save of the same chapter "
                 "to force the same state.")
        theme.label(side, steps, 9, theme.FG, wraplength=int(320 * self.app.s)).pack(anchor="w")

    # drawing
    def refresh(self):
        names = [f.name for f in saves.list_save_files()]
        self.picker.set_choices(names)
        snap = config.read_json(SNAP_FILE, None)
        self.snap_lbl.config(text=f"Snapshot held: {snap['file']} ({len(snap['lines'])} lines)"
                             if snap else "No snapshot held.")
        for w in self.cards.inner.winfo_children():
            w.destroy()
        presets = saves.load_presets()
        if not presets:
            theme.label(self.cards.inner,
                        "\n  No presets yet.\n\n"
                        "  Record one below, or import presets someone shared.",
                        11, theme.DIM).pack(anchor="w")
        for i, p in enumerate(presets):
            edge = tk.Frame(self.cards.inner, bg=theme.FAINT, padx=1, pady=1)
            edge.pack(fill="x", pady=4, padx=(0, 8))
            card = tk.Frame(edge, bg=theme.BG, padx=12, pady=8)
            card.pack(fill="x")
            info = tk.Frame(card, bg=theme.BG)
            info.pack(side="left", fill="x", expand=True)
            theme.label(info, p.get("name", "?").upper(), 11, theme.FG, True).pack(anchor="w")
            theme.label(info, f"{p.get('chapter', 'any chapter')}  |  "
                              f"{len(p.get('edits', []))} line(s)", 9, theme.DIM).pack(anchor="w")
            if p.get("description"):
                theme.label(info, p["description"], 9, theme.FG, wraplength=480).pack(anchor="w")
            theme.GButton(card, "X", lambda i=i: self.delete(i), danger=True).pack(side="right", padx=(6, 0))
            theme.GButton(card, "INVOKE", lambda p=p: self.invoke(p), big=True).pack(side="right")

    # actions
    def _target(self):
        name = self.picker.value
        if not name:
            theme.error(self.app.root, "No save", "No chapter save files were found.")
            return None
        return paths.save_dir() / name

    def invoke(self, preset):
        path = self._target()
        if not path:
            return
        try:
            n = saves.apply_preset(preset, saves.SaveFile(path))
        except Exception as exc:
            theme.error(self.app.root, "The secret refused", str(exc))
            return
        self.app.say(f"Applied {preset['name']} to {path.name} ({n} lines).")
        self.app.refresh_all()

    def delete(self, i):
        presets = saves.load_presets()
        if theme.confirm(self.app.root, "Forget secret",
                         f"Delete the preset {presets[i].get('name')}?", danger=True):
            presets.pop(i)
            saves.save_presets(presets)
            self.refresh()

    def take_snapshot(self):
        path = self._target()
        if not path:
            return
        s = saves.SaveFile(path)
        config.write_json(SNAP_FILE, {"file": path.name, "chapter": s.chapter_key, "lines": s.lines})
        self.app.say("Snapshot taken. Now go change something in-game.")
        self.refresh()

    def compare(self):
        snap = config.read_json(SNAP_FILE, None)
        if not snap:
            theme.info(self.app.root, "No snapshot", "Press TAKE SNAPSHOT first.")
            return
        path = paths.save_dir() / snap["file"]
        if not path.exists():
            theme.error(self.app.root, "Missing", f"{snap['file']} no longer exists.")
            return
        now = saves.SaveFile(path)
        diff = saves.diff_lines(snap["lines"], now.lines)
        if not diff:
            theme.info(self.app.root, "Nothing changed",
                       "The save is identical to the snapshot. Did you save in-game?")
            return
        RecordDialog(self.app, snap, diff, self.refresh)

    def import_presets(self):
        f = filedialog.askopenfilename(title="Import presets", filetypes=[("Presets", "*.json")])
        if not f:
            return
        try:
            data = json.load(open(f, encoding="utf-8"))
            assert isinstance(data, list)
            for p in data:
                assert isinstance(p.get("name"), str)
                for e in p.get("edits", []):
                    int(e["line"]), str(e["value"])
        except Exception:
            theme.error(self.app.root, "Bad file", "That isn't a valid presets file.")
            return
        presets = saves.load_presets() + data
        saves.save_presets(presets)
        self.refresh()
        self.app.say(f"Imported {len(data)} preset(s).")

    def export_presets(self):
        f = filedialog.asksaveasfilename(title="Export presets", defaultextension=".json",
                                         filetypes=[("Presets", "*.json")])
        if f:
            config.write_json(f, saves.load_presets())
            self.app.say("Presets exported.")


class RecordDialog(tk.Toplevel):
    """Shows changed lines with checkboxes; saves the ticked ones as a preset."""

    def __init__(self, app, snap, diff, on_saved):
        super().__init__(app.root)
        self.app, self.snap, self.on_saved = app, snap, on_saved
        self.overrideredirect(True)
        self.configure(bg=theme.FG)
        body = tk.Frame(self, bg=theme.BG, padx=22, pady=16)
        body.pack(padx=2, pady=2, fill="both", expand=True)
        theme.label(body, "WHAT CHANGED", 13, theme.FG, True).pack(anchor="w")
        theme.rule(body).pack(fill="x", pady=(6, 8))
        theme.label(body, f"{len(diff)} line(s) differ in {snap['file']}. Tick the ones that make "
                          "the secret happen (things like play-time counters can be left out).",
                    9, theme.DIM, wraplength=560).pack(anchor="w")
        labels = saves.load_labels().get(snap["chapter"], {})
        area = theme.ScrollFrame(body, height=280, width=580)
        area.pack(fill="both", expand=True, pady=8)
        self.checks = []
        for i, old, new in diff[:400]:
            row = tk.Frame(area.inner, bg=theme.BG)
            row.pack(fill="x")
            c = theme.GCheck(row, True)
            c.pack(side="left")
            name = labels.get(str(i), "")
            theme.label(row, f" line {i:<5} {name[:14]:<14} {old[:16]:>16}  ->  {new[:24]}",
                        9, theme.FG).pack(side="left")
            self.checks.append((c, i, new))
        theme.label(body, "NAME", 9, theme.DIM).pack(anchor="w")
        self.name_e = theme.entry(body, 50)
        self.name_e.pack(anchor="w", fill="x")
        theme.label(body, "DESCRIPTION", 9, theme.DIM).pack(anchor="w", pady=(6, 0))
        self.desc_e = theme.entry(body, 50)
        self.desc_e.pack(anchor="w", fill="x")
        row = tk.Frame(body, bg=theme.BG)
        row.pack(anchor="e", pady=(12, 0))
        theme.GButton(row, "SAVE AS PRESET", self.save).pack(side="left", padx=4)
        theme.GButton(row, "CANCEL", self.close).pack(side="left")
        self.update_idletasks()
        x = app.root.winfo_rootx() + (app.root.winfo_width() - self.winfo_reqwidth()) // 2
        y = app.root.winfo_rooty() + (app.root.winfo_height() - self.winfo_reqheight()) // 2
        self.geometry(f"+{max(x, 0)}+{max(y, 0)}")
        self.grab_set()
        self.name_e.focus_set()

    def save(self):
        name = self.name_e.get().strip()
        edits = [{"line": i, "value": v} for c, i, v in self.checks if c.checked]
        if not name or not edits:
            theme.error(self.app.root, "Incomplete", "Give it a name and tick at least one line.")
            return
        presets = saves.load_presets()
        presets.append({"name": name, "description": self.desc_e.get().strip(),
                        "chapter": self.snap["chapter"], "edits": edits})
        saves.save_presets(presets)
        self.app.say(f"Saved preset: {name}.")
        self.close()
        self.on_saved()

    def close(self):
        self.grab_release()
        self.destroy()
