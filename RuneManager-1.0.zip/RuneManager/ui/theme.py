"""Colours and widgets. Black + white + pixel text."""
import tkinter as tk
import tkinter.font as tkfont

BG = "#030212"          # panel black with a hint of the indigo background
FG = "#ffffff"
DIM = "#8f8cad"         # dusty lavender for secondary text
FAINT = "#2b2947"       # thin dividers, disabled things
SHADOW = "#2c2a4e"      # drop shadow under pixel text
RED = "#ff4a4a"
GOLD = "#ffd24a"
SCALE = 1.0             # set by the app from Windows display scaling


def px(n):
    return max(1, round(n * SCALE))

_FONT_FAMILY = None


def family():
    """First good monospace font installed on this machine."""
    global _FONT_FAMILY
    if _FONT_FAMILY is None:
        have = set(tkfont.families())
        for f in ("Determination Mono", "8bitoperator JVE", "Consolas", "Lucida Console",
                  "Courier New", "DejaVu Sans Mono", "Liberation Mono", "Courier"):
            if f in have:
                _FONT_FAMILY = f
                break
        else:
            _FONT_FAMILY = "Courier"
    return _FONT_FAMILY


def font(size=11, bold=False):
    return (family(), size, "bold" if bold else "normal")


# widgets
class GButton(tk.Frame):
    """White-outlined pixel-text button that inverts on hover."""

    def __init__(self, parent, text, command=None, big=False, danger=False, width=None,
                 huge=False):
        # outer frame = invisible margin so buttons never touch each other
        super().__init__(parent, bg=parent.cget("bg"), padx=px(3), pady=px(3))
        self.edge_frame = tk.Frame(self, bg=RED if danger else FG, padx=1, pady=1)
        self.edge_frame.pack(fill="both", expand=True)
        self.command = command
        self.enabled = True
        self.big = big
        self.huge = huge
        self.scale = 4 if huge else (3 if big else 2)
        self.edge = RED if danger else FG
        self.text = text
        self.pad = px(20 if huge else (14 if big else 8))
        self.label = tk.Label(self.edge_frame, bg=BG, bd=0, cursor="hand2",
                              padx=self.pad, pady=px(11 if huge else (7 if big else 4)))
        self.label.pack(fill="both", expand=True)
        # old API: width given in characters -> a minimum width, rea
        self._min_w = int(width * px(self.scale) * 4) if width else 0
        self._draw(self.edge, BG)
        for w in (self, self.edge_frame, self.label):
            w.bind("<Enter>", self._hover)
            w.bind("<Leave>", self._leave)
            w.bind("<Button-1>", self._click)

    def _draw(self, fg, bg):
        from . import pixelfont as pf
        if pf.supported(self.text):
            self._img = pf.render(self.text, px(self.scale), fg, None, 1)
            self.label.config(image=self._img, bg=bg, text="", compound="center")
        else:
            self.label.config(text=self.text, fg=fg, bg=bg, image="",
                              font=font(16 if self.huge else (13 if self.big else 10), True))
        if self._min_w:
            from . import pixelfont as pf
            tw = pf.text_size(self.text, px(self.scale))[0]
            self.label.config(padx=max(self.pad, (self._min_w - tw) // 2))

    def _hover(self, _e=None):
        if self.enabled:
            self._draw(BG, self.edge)

    def _leave(self, _e=None):
        self._draw(self.edge if self.enabled else FAINT, BG)

    def _click(self, _e=None):
        if self.enabled and self.command:
            self._leave()
            self.command()

    def set_enabled(self, on):
        self.enabled = on
        self.edge_frame.config(bg=self.edge if on else FAINT)
        self._draw(self.edge if on else FAINT, BG)
        self.label.config(cursor="hand2" if on else "arrow")

    def set_text(self, text):
        self.text = text
        self._leave()


class GCheck(tk.Label):
    """[X] / [ ] checkbox."""

    def __init__(self, parent, checked=False, command=None, fg=FG):
        super().__init__(parent, bg=BG, fg=fg, font=font(11, True), cursor="hand2")
        self.checked = checked
        self.command = command
        self.bind("<Button-1>", self.toggle)
        self._draw()

    def _draw(self):
        self.config(text="[X]" if self.checked else "[ ]")

    def toggle(self, _e=None):
        self.checked = not self.checked
        self._draw()
        if self.command:
            self.command(self.checked)


def label(parent, text="", size=10, color=FG, bold=False, **kw):
    from . import pixelfont as pf
    if bold and size >= 11 and text and pf.supported(text) and "wraplength" not in kw:
        scale = 3 if size >= 14 else 2
        return pf.PixelLabel(parent, text.upper(), scale=px(scale), color=color,
                             shadow=SHADOW, bg=BG, anchor=kw.get("anchor", "w"))
    return tk.Label(parent, text=text, bg=BG, fg=color, font=font(size, bold),
                    justify="left", anchor=kw.pop("anchor", "nw"), **kw)


def entry(parent, width=30, **kw):
    return tk.Entry(parent, width=width, bg=BG, fg=FG, insertbackground=FG,
                    relief="flat", highlightthickness=1, highlightbackground=DIM,
                    highlightcolor=FG, font=font(11), selectbackground=FG,
                    selectforeground=BG, **kw)


def textbox(parent, height=4, **kw):
    kw.setdefault("width", 20)   # small request; the layout stretches it to fit
    return tk.Text(parent, height=height, bg=BG, fg=FG, insertbackground=FG,
                   relief="flat", highlightthickness=1, highlightbackground=DIM,
                   highlightcolor=FG, font=font(10), wrap=kw.pop("wrap", "word"),
                   selectbackground=FG, selectforeground=BG, **kw)


def listbox(parent, **kw):
    return tk.Listbox(parent, bg=BG, fg=FG, selectbackground=FG, selectforeground=BG,
                      relief="flat", highlightthickness=1, highlightbackground=DIM,
                      highlightcolor=FG, font=font(10), activestyle="none", **kw)


def rule(parent):
    return tk.Frame(parent, bg=FAINT, height=1)


class Dropdown(GButton):
    """Button that opens a themed popup menu of choices."""

    def __init__(self, parent, choices, on_pick, width=28):
        self.choices = list(choices)
        self.on_pick = on_pick
        self.value = self.choices[0] if self.choices else ""
        super().__init__(parent, self._caption(), self._open, width=width)

    def _caption(self):
        return (self.value or "-") + "  v"

    def set_choices(self, choices, keep=True):
        self.choices = list(choices)
        if not keep or self.value not in self.choices:
            self.value = self.choices[0] if self.choices else ""
        self.set_text(self._caption())

    def set_value(self, value):
        self.value = value
        self.set_text(self._caption())

    def _open(self):
        if not self.choices:
            return
        m = tk.Menu(self, tearoff=0, bg=BG, fg=FG, activebackground=FG,
                    activeforeground=BG, font=font(10), relief="flat", bd=1)
        for c in self.choices:
            m.add_command(label=c, command=lambda c=c: self._pick(c))
        m.tk_popup(self.winfo_rootx(), self.winfo_rooty() + self.winfo_height())

    def _pick(self, c):
        self.set_value(c)
        self.on_pick(c)


class ScrollFrame(tk.Frame):
    """Scrolling area with a slim scrollbar. Children go in .inner."""

    def __init__(self, parent, **kw):
        super().__init__(parent, bg=BG, **kw)
        self.canvas = tk.Canvas(self, bg=BG, highlightthickness=0, bd=0)
        self.bar = tk.Canvas(self, bg=BG, width=6, highlightthickness=0, bd=0)
        self.inner = tk.Frame(self.canvas, bg=BG)
        self._win = self.canvas.create_window(0, 0, window=self.inner, anchor="nw")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.bar.pack(side="right", fill="y")
        self.inner.bind("<Configure>", self._update)
        self.canvas.bind("<Configure>", self._resize)
        self.bar.bind("<B1-Motion>", self._drag)
        self.bar.bind("<Button-1>", self._drag)
        for w in (self.canvas, self.inner):
            w.bind("<Enter>", lambda e: self._wheel(True))
            w.bind("<Leave>", lambda e: self._wheel(False))

    def _resize(self, e):
        self.canvas.itemconfigure(self._win, width=e.width)
        self._update()

    def _update(self, _e=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all") or (0, 0, 0, 0))
        self._draw_bar()

    def _draw_bar(self):
        self.bar.delete("all")
        top, bottom = self.canvas.yview()
        if bottom - top >= 0.999:
            return
        h = self.bar.winfo_height()
        self.bar.create_rectangle(1, top * h, 5, bottom * h, fill=FG, outline="")

    def _drag(self, e):
        h = max(self.bar.winfo_height(), 1)
        top, bottom = self.canvas.yview()
        self.canvas.yview_moveto(max(0, e.y / h - (bottom - top) / 2))
        self._draw_bar()

    def _wheel(self, on):
        if on:
            self.canvas.bind_all("<MouseWheel>", self._on_wheel)
            self.canvas.bind_all("<Button-4>", lambda e: self._scroll(-1))
            self.canvas.bind_all("<Button-5>", lambda e: self._scroll(1))
        else:
            self.canvas.unbind_all("<MouseWheel>")
            self.canvas.unbind_all("<Button-4>")
            self.canvas.unbind_all("<Button-5>")

    def _on_wheel(self, e):
        self._scroll(-1 if e.delta > 0 else 1)

    def _scroll(self, n):
        if self.canvas.yview() != (0.0, 1.0):
            self.canvas.yview_scroll(n * 2, "units")
            self._draw_bar()

    def to_top(self):
        self.canvas.yview_moveto(0)
        self._draw_bar()


# dialogs
class GDialog(tk.Toplevel):
    """
    Themed modal dialog. ask(...) returns the pressed button text (or None),
    plus the entry values if `fields` were given.
    """

    def __init__(self, parent, title, message, buttons=("OK",), fields=None, danger=False):
        super().__init__(parent)
        self.withdraw()
        self.overrideredirect(True)
        self.configure(bg=RED if danger else FG)
        self.result = None
        self.values = {}
        body = tk.Frame(self, bg=BG, padx=26, pady=20)
        body.pack(padx=2, pady=2, fill="both", expand=True)
        label(body, title.upper(), 13, RED if danger else FG, True).pack(anchor="w")
        rule(body).pack(fill="x", pady=(6, 12))
        label(body, message, 10, FG, wraplength=520).pack(anchor="w")
        self.entries = {}
        for key, (caption, default) in (fields or {}).items():
            label(body, caption, 9, DIM).pack(anchor="w", pady=(10, 2))
            e = entry(body, 56)
            e.insert(0, default)
            e.pack(anchor="w", fill="x")
            self.entries[key] = e
        row = tk.Frame(body, bg=BG)
        row.pack(anchor="e", pady=(18, 0))
        for b in buttons:
            GButton(row, b, lambda b=b: self._done(b)).pack(side="left", padx=(8, 0))
        self.bind("<Escape>", lambda e: self._done(None))
        self.bind("<Return>", lambda e: self._done(buttons[0]))
        self.update_idletasks()
        px = parent.winfo_rootx() + (parent.winfo_width() - self.winfo_reqwidth()) // 2
        py = parent.winfo_rooty() + (parent.winfo_height() - self.winfo_reqheight()) // 2
        self.geometry(f"+{max(px, 0)}+{max(py, 0)}")
        self.deiconify()
        self.lift()
        self.grab_set()
        if self.entries:
            next(iter(self.entries.values())).focus_set()
        else:
            self.focus_set()

    def _done(self, b):
        self.result = b
        self.values = {k: e.get() for k, e in self.entries.items()}
        self.grab_release()
        self.destroy()


def ask(parent, title, message, buttons=("OK",), fields=None, danger=False):
    d = GDialog(parent, title, message, buttons, fields, danger)
    parent.wait_window(d)
    return (d.result, d.values) if fields else d.result


def info(parent, title, message):
    ask(parent, title, message, ("OK",))


def error(parent, title, message):
    ask(parent, title, message, ("OK",), danger=True)


def confirm(parent, title, message, yes="YES", no="NO", danger=False):
    return ask(parent, title, message, (yes, no), danger=danger) == yes


def choose(parent, title, message, options, ok="CHOOSE", width=60, height=10):
    """Themed list picker. Returns the chosen index or None."""
    if not options:
        return None
    top = tk.Toplevel(parent)
    top.withdraw()
    top.overrideredirect(True)
    top.configure(bg=FG)
    body = tk.Frame(top, bg=BG, padx=24, pady=18)
    body.pack(padx=2, pady=2)
    label(body, title.upper(), 13, FG, True).pack(anchor="w")
    rule(body).pack(fill="x", pady=(6, 10))
    label(body, message, 10, wraplength=520).pack(anchor="w")
    lb = listbox(body, width=width, height=min(height, max(len(options), 3)))
    lb.pack(pady=10, fill="x")
    for o in options:
        lb.insert("end", " " + o)
    lb.selection_set(0)
    result = {"v": None}

    def done(ok_pressed):
        if ok_pressed and lb.curselection():
            result["v"] = lb.curselection()[0]
        top.grab_release()
        top.destroy()
    lb.bind("<Double-Button-1>", lambda e: done(True))
    row = tk.Frame(body, bg=BG)
    row.pack(anchor="e")
    GButton(row, ok, lambda: done(True)).pack(side="left", padx=4)
    GButton(row, "CANCEL", lambda: done(False)).pack(side="left")
    top.bind("<Escape>", lambda e: done(False))
    top.update_idletasks()
    x = parent.winfo_rootx() + (parent.winfo_width() - top.winfo_reqwidth()) // 2
    y = parent.winfo_rooty() + (parent.winfo_height() - top.winfo_reqheight()) // 2
    top.geometry(f"+{max(x, 0)}+{max(y, 0)}")
    top.deiconify()
    top.grab_set()
    top.focus_set()
    parent.wait_window(top)
    return result["v"]
