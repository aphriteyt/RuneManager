"""MODS tab."""
import tkinter as tk
from tkinter import filedialog

from core import backup, config, mods, paths
from . import theme
from .app import Tab


class ModsTab(Tab):
    def build(self):
        self.heading(self, "INSTALLED MODS",
                     "Lower in the list applies later. Red = two mods want the same file.")
        btns = tk.Frame(self, bg=theme.BG)
        btns.pack(fill="x", pady=(0, 8))
        theme.GButton(btns, "IMPORT MOD FILE", self.import_file).pack(side="left", padx=(0, 8))
        theme.GButton(btns, "OPEN MODS FOLDER",
                      lambda: paths.open_folder(config.MODS_DIR)).pack(side="left", padx=(0, 8))
        theme.GButton(btns, "RESCAN", self.rescan).pack(side="left")

        bottom = tk.Frame(self, bg=theme.BG)
        bottom.pack(side="bottom", fill="x", pady=(10, 0))
        self.log = theme.textbox(bottom, height=3)
        self.log.pack(side="left", fill="x", expand=True, padx=(0, 16))
        right = tk.Frame(bottom, bg=theme.BG)
        right.pack(side="right", before=self.log)
        self.pending_lbl = theme.label(right, "", 9, theme.GOLD)
        self.pending_lbl.pack(anchor="e", pady=(0, 6))
        self.apply_btn = theme.GButton(right, "APPLY CHANGES", self.apply, big=True, width=18)
        self.apply_btn.pack(anchor="e")

        self.list = theme.ScrollFrame(self)
        self.list.pack(fill="both", expand=True)

    # list
    def refresh(self):
        app = self.app
        # .bps mods are checked against checksums of the big game files. Measure
        todo = mods.files_needing_checksum(list(app.mods.values()), app.game_dir, app.cache)
        if todo:
            if not getattr(self, "_warming", False):
                self._warming = True
                for w in self.list.inner.winfo_children():
                    w.destroy()
                theme.label(self.list.inner, "\n  MEASURING YOUR GAME FILES...", 11,
                            theme.DIM).pack(anchor="w")

                def done(found):
                    self._warming = False
                    app.cache.update(found)      # merge on the UI thread (thread-safe)
                    app.cfg.save()
                    self.refresh()

                def fail(_exc):
                    self._warming = False
                app.run_bg(lambda: mods.warm_checksums(todo, {}), done, fail)
            return
        for w in self.list.inner.winfo_children():
            w.destroy()
        order = app.cfg["load_order"]
        enabled = set(app.cfg["enabled"])
        enabled_mods = [app.mods[i] for i in order if i in enabled and i in app.mods]
        conflicts = mods.find_conflicts(enabled_mods)

        if not order:
            theme.label(self.list.inner, "\n  No mods installed yet.\n\n"
                        "  Import a .zip / .xdelta / data.win / .dll with IMPORT MOD FILE,\n"
                        "  or grab one from the DOWNLOAD tab.", 11, theme.DIM).pack(anchor="w")
        for idx, mod_id in enumerate(order):
            self._row(app.mods[mod_id], idx, mod_id in enabled, conflicts.get(mod_id))
        self.list.to_top()
        self._update_pending()

    def _row(self, mod, idx, on, conflict):
        color = theme.RED if conflict else (theme.FG if on else theme.DIM)
        edge = tk.Frame(self.list.inner, bg=theme.RED if conflict else theme.FAINT, padx=1, pady=1)
        edge.pack(fill="x", pady=4, padx=(0, 8))
        row = tk.Frame(edge, bg=theme.BG, padx=10, pady=6)
        row.pack(fill="x")

        theme.GCheck(row, on, lambda v, m=mod: self.toggle(m.id, v), fg=color).pack(side="left", anchor="n")
        side = tk.Frame(row, bg=theme.BG)
        side.pack(side="right", anchor="n")          # claim the buttons' width first
        mid = tk.Frame(row, bg=theme.BG)
        mid.pack(side="left", fill="x", expand=True, padx=10)
        theme.label(mid, f"{mod.name.upper()}   v{mod.version.lstrip('vV')}", 11, color, True).pack(anchor="w")
        theme.label(mid, f"by {mod.author}  |  changes {mod.summary()}",
                    9, theme.DIM, wraplength=int(640 * self.app.s)).pack(anchor="w")
        if mod.description and mod.description != "Auto-imported.":
            theme.label(mid, mod.description, 9, theme.DIM,
                        wraplength=int(640 * self.app.s)).pack(anchor="w")
        if conflict:
            for target, others in conflict:
                names = ", ".join(self.app.mods[o].name for o in others)
                theme.label(mid, f"CONFLICT: also changed by {names}  ({target})", 9,
                            theme.RED, wraplength=int(640 * self.app.s)).pack(anchor="w")
        for req, why in mods.missing_requirements(mod, self.app.mods,
                                                  set(self.app.cfg["enabled"])):
            theme.label(mid, f"! Needs {req['name']} ({why})", 9, theme.GOLD,
                        wraplength=int(640 * self.app.s)).pack(anchor="w")
        errors, warnings = mods.check_mod(mod, self.app.game_dir, self.app.cfg, self.app.cache)
        for e in errors:
            theme.label(mid, "x " + e, 9, theme.RED, wraplength=int(640 * self.app.s)).pack(anchor="w")
        for w in warnings:
            theme.label(mid, "! " + w, 9, theme.GOLD, wraplength=int(640 * self.app.s)).pack(anchor="w")

        theme.GButton(side, "UP", lambda: self.move(mod.id, -1)).pack(side="left", padx=2)
        theme.GButton(side, "DOWN", lambda: self.move(mod.id, 1)).pack(side="left", padx=2)
        if mod.needs_target() or any(op["type"] in ("xdelta", "replace") for op in mod.operations):
            theme.GButton(side, "SET TARGET", lambda: self.set_target(mod)).pack(side="left", padx=2)
        theme.GButton(side, "REMOVE", lambda: self.remove(mod), danger=True).pack(side="left", padx=2)

    def _update_pending(self):
        applied = config.read_json(config.APPLIED_FILE, {}).get("enabled", [])
        want = [i for i in self.app.cfg["load_order"] if i in self.app.cfg["enabled"]]
        self.pending_lbl.config(text="UNAPPLIED CHANGES" if applied != want else "IN SYNC")

    def write_log(self, text):
        self.log.insert("end", text + "\n")
        self.log.see("end")

    # actions
    def toggle(self, mod_id, value):
        en = self.app.cfg["enabled"]
        if value and mod_id not in en:
            en.append(mod_id)
        if not value and mod_id in en:
            en.remove(mod_id)
        self.app.cfg.save()
        self.refresh()

    def move(self, mod_id, d):
        order = self.app.cfg["load_order"]
        i = order.index(mod_id)
        j = max(0, min(len(order) - 1, i + d))
        order[i], order[j] = order[j], order[i]
        self.app.cfg.save()
        self.refresh()

    def rescan(self):
        self.app.reload_mods()
        self.refresh()
        self.app.say("Rescanned the mods folder.")

    def import_file(self):
        f = filedialog.askopenfilename(
            title="Choose a mod", filetypes=[("Mods", "*.zip *.xdelta *.vcdiff *.win *.dll"),
                                             ("All files", "*.*")])
        if not f:
            return
        self.app.say("Importing...")
        backup.snapshot_saves("before-import")
        self.app.run_bg(lambda: mods.import_mod(f, self.app.game_dir, cache=self.app.cache),
                        self._imported)

    def _imported(self, result):
        mod, notes = result
        self.app.reload_mods()
        if mod.id not in self.app.cfg["enabled"]:
            self.app.cfg["enabled"].append(mod.id)
            self.app.cfg.save()
        self.app.refresh_all()
        self.app.say(f"Imported {mod.name} - press Apply.")
        if notes:
            theme.info(self.app.root, "Imported", "\n".join(notes))

    def set_target(self, mod):
        targets = paths.find_data_wins(self.app.game_dir)
        ops = [op for op in mod.operations if op["type"] != "copy"]
        for op in ops:
            i = theme.choose(self.app.root, "Set target",
                             f"Which game file does\n{op['file']}\npatch?", targets, ok="SET")
            if i is None:
                return
            op["target"] = targets[i]
        mod.save()
        self.refresh()

    def remove(self, mod):
        if not theme.confirm(self.app.root, "Remove mod",
                             f"Delete {mod.name} from the mods folder?\n"
                             "(Press APPLY afterwards to take it out of the game.)", danger=True):
            return
        mods.remove_mod(mod.id)
        self.app.reload_mods()
        self.app.refresh_all()

    def apply(self):
        app = self.app
        want = [i for i in app.cfg["load_order"] if i in app.cfg["enabled"]]
        enabled_mods = [app.mods[i] for i in want]
        if mods.find_conflicts(enabled_mods):
            theme.error(app.root, "Conflict",
                        "Mods marked in red change the same game file. Untick one of them first.")
            return
        warn = []
        for m in enabled_mods:
            errors, warnings = mods.check_mod(m, app.game_dir, app.cfg, app.cache)
            if errors:
                theme.error(app.root, "Can't apply", f"{m.name}:\n\n" + "\n".join(errors))
                return
            warn += [f"{m.name}: {w}" for w in warnings]
        if warn and not theme.confirm(app.root, "Are you sure?",
                                      "\n\n".join(warn) + "\n\nApply anyway?",
                                      yes="APPLY ANYWAY", no="CANCEL"):
            return
        if paths.is_game_running():
            theme.error(app.root, "Game running", "Close DELTARUNE before applying mods.")
            return
        self.apply_btn.set_enabled(False)
        self.log.delete("1.0", "end")
        app.say("Applying...")

        def work():
            backup.snapshot_saves("before-apply")
            return mods.apply_loadout(app.game_dir, app.mods, want, app.cfg, app.cache,
                                      log=lambda t: app.call_ui(self.write_log, t))

        def done(n):
            self.apply_btn.set_enabled(True)
            app.cfg.save()
            app.refresh_all()
            app.say(f"{n} mod(s) active." if n else "No mods active - game is vanilla.")

        def fail(exc):
            self.apply_btn.set_enabled(True)
            self.write_log("FAILED: " + str(exc))
            theme.error(app.root, "Apply failed", str(exc) +
                        "\n\nYour game files were rolled back to vanilla.")
            app.refresh_all()
        app.run_bg(work, done, fail)
