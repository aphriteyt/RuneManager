"""SAVES tab - the save editor."""
import tkinter as tk

from core import paths, saves
from . import theme
from .app import Tab


class SavesTab(Tab):
    def build(self):
        self.save = None
        self.hits = None          # result of last FIND (list of indexes) or None
        self.visible = []         # listbox row -> line index

        top = tk.Frame(self, bg=theme.BG)
        top.pack(fill="x")
        hd = tk.Frame(top, bg=theme.BG)
        hd.pack(side="left", fill="x", expand=True)
        self.heading(hd, "SAVE EDITOR", "Close DELTARUNE first - it overwrites saves while running.")
        right = tk.Frame(top, bg=theme.BG)
        right.pack(side="right", anchor="n", before=hd)
        self.picker = theme.Dropdown(right, [], self.pick, width=18)
        self.picker.pack(side="left", padx=4)
        theme.GButton(right, "RELOAD", self.reload).pack(side="left", padx=4)
        self.write_btn = theme.GButton(right, "WRITE TO SAVE", self.write)
        self.write_btn.pack(side="left", padx=4)
        theme.GButton(right, "OPEN FOLDER", lambda: paths.open_folder(paths.save_dir())
                      if paths.save_dir().exists() else None).pack(side="left", padx=4)

        body = tk.Frame(self, bg=theme.BG)
        body.pack(fill="both", expand=True)

        side = tk.Frame(body, bg=theme.BG, width=int(360 * self.app.s))
        side.pack(side="right", fill="y")
        side.pack_propagate(False)
        # left: finder + all lines
        left = tk.Frame(body, bg=theme.BG)
        left.pack(side="left", fill="both", expand=True, padx=(0, 18))
        f1 = tk.Frame(left, bg=theme.BG)
        f1.pack(fill="x", pady=(0, 6))
        theme.label(f1, "FIND VALUE", 9, theme.DIM).pack(side="left")
        self.find_e = theme.entry(f1, 12)
        self.find_e.pack(side="left", padx=6)
        self.find_e.bind("<Return>", lambda e: self.find(False))
        theme.GButton(f1, "FIND", lambda: self.find(False)).pack(side="left", padx=2)
        theme.GButton(f1, "NARROW", lambda: self.find(True)).pack(side="left", padx=2)
        theme.GButton(f1, "SHOW ALL", self.clear_find).pack(side="left", padx=2)
        self.hits_lbl = theme.label(f1, "", 9, theme.GOLD)
        self.hits_lbl.pack(side="left", padx=8)
        self.dirty_lbl = theme.label(f1, "", 9, theme.GOLD)
        self.dirty_lbl.pack(side="right")
        theme.label(left, "How to find something: type the number you see in-game and FIND. Too many "
                    "matches? Change it in-game (spend money, take damage), save, RELOAD, type the "
                    "new number and NARROW.", 8, theme.DIM, wraplength=560).pack(anchor="w", pady=(0, 6))
        lf = tk.Frame(left, bg=theme.BG)
        lf.pack(fill="both", expand=True)
        self.lb = theme.listbox(lf)
        sb = tk.Scrollbar(lf, command=self.lb.yview)
        self.lb.config(yscrollcommand=sb.set)
        self.lb.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.lb.bind("<<ListboxSelect>>", self.select)

        # right: selected line + named values

        theme.label(side, "SELECTED LINE", 11, theme.FG, True).pack(anchor="w")
        self.sel_lbl = theme.label(side, "-", 9, theme.DIM)
        self.sel_lbl.pack(anchor="w", pady=(2, 6))
        theme.label(side, "VALUE", 9, theme.DIM).pack(anchor="w")
        self.val_e = theme.entry(side, 34)
        self.val_e.pack(anchor="w", fill="x")
        self.val_e.bind("<Return>", lambda e: self.set_value())
        theme.label(side, "NAME (e.g. DARK DOLLARS, KRIS MAX HP)", 9, theme.DIM).pack(anchor="w", pady=(6, 0))
        self.name_e = theme.entry(side, 34)
        self.name_e.pack(anchor="w", fill="x")
        r = tk.Frame(side, bg=theme.BG)
        r.pack(anchor="w", pady=8)
        theme.GButton(r, "SET VALUE", self.set_value).pack(side="left", padx=(0, 6))
        theme.GButton(r, "SAVE NAME", self.set_name).pack(side="left")

        theme.rule(side).pack(fill="x", pady=8)
        theme.label(side, "NAMED VALUES", 11, theme.FG, True).pack(anchor="w")
        theme.label(side, "Your bookmarks for this chapter. Click to jump.", 8,
                    theme.DIM).pack(anchor="w")
        self.named = theme.ScrollFrame(side)
        self.named.pack(fill="both", expand=True, pady=6)


    # loading
    def refresh(self):
        files = saves.list_save_files()
        names = [f.name for f in files]
        self.picker.set_choices(names)
        if not names:
            self.save = None
            self.lb.delete(0, "end")
            self.lb.insert("end", f"  No chapter saves found in {paths.save_dir()}")
            self._draw_named()
            return
        if self.save is None or self.save.path.name not in names:
            self.pick(self.picker.value)
        else:
            self._draw()

    def pick(self, name):
        if self.save is not None and self.save.dirty:
            if not theme.confirm(self.app.root, "Unsaved edits",
                                 "Discard the edits you haven't written yet?"):
                self.picker.set_value(self.save.path.name)
                return
        try:
            self.save = saves.SaveFile(paths.save_dir() / name)
        except OSError as exc:
            theme.error(self.app.root, "Can't read save", str(exc))
            return
        self.app.selected_save = name
        self.hits = None
        self.hits_lbl.config(text="")
        self._draw()

    def reload(self):
        if self.save is not None:
            name = self.save.path.name
            self.save = None
            self.refresh()
            if name in self.picker.choices:
                self.picker.set_value(name)
                self.pick(name)

    def _labels(self):
        return saves.load_labels().get(self.save.chapter_key, {}) if self.save else {}

    def _draw(self):
        labels = self._labels()
        self.lb.delete(0, "end")
        idxs = self.hits if self.hits is not None else range(len(self.save.lines))
        self.visible = list(idxs)
        for i in self.visible:
            name = labels.get(str(i), "")
            changed = "*" if (i < len(self.save.original) and
                              self.save.lines[i] != self.save.original[i]) else " "
            self.lb.insert("end", f"{changed}{i:5d}  {name[:18]:<18}  {self.save.lines[i]}")
        self._draw_named()
        self.dirty_lbl.config(text="UNWRITTEN CHANGES" if self.save.dirty else "")

    def _draw_named(self):
        for w in self.named.inner.winfo_children():
            w.destroy()
        if not self.save:
            return
        labels = self._labels()
        if not labels:
            theme.label(self.named.inner, "None yet. Select a line and SAVE NAME.", 9,
                        theme.DIM).pack(anchor="w")
        for idx, name in sorted(labels.items(), key=lambda kv: kv[1]):
            i = int(idx)
            if i >= len(self.save.lines):
                continue
            row = tk.Frame(self.named.inner, bg=theme.BG, cursor="hand2")
            row.pack(fill="x", pady=1)
            a = theme.label(row, name.upper()[:20], 9, theme.FG, True)
            a.pack(side="left")
            b = theme.label(row, self.save.lines[i], 9, theme.DIM)
            b.pack(side="right")
            for w in (row, a, b):
                w.bind("<Button-1>", lambda e, i=i: self.jump(i))

    # editing
    def jump(self, i):
        self.hits = None
        self.hits_lbl.config(text="")
        self._draw()
        self.lb.selection_clear(0, "end")
        self.lb.selection_set(i)
        self.lb.see(i)
        self.select()

    def _selected_index(self):
        sel = self.lb.curselection()
        if not sel or not self.save or sel[0] >= len(self.visible):
            return None
        return self.visible[sel[0]]

    def select(self, _e=None):
        i = self._selected_index()
        if i is None:
            return
        self.sel_lbl.config(text=f"LINE {i}  (original: {self.save.original[i] if i < len(self.save.original) else '-'})")
        self.val_e.delete(0, "end")
        self.val_e.insert(0, self.save.lines[i])
        self.name_e.delete(0, "end")
        self.name_e.insert(0, self._labels().get(str(i), ""))

    def set_value(self):
        i = self._selected_index()
        if i is None:
            return
        try:
            self.save.set(i, self.val_e.get())
        except ValueError as exc:
            theme.error(self.app.root, "Bad value", str(exc))
            return
        pos = self.lb.curselection()[0]
        self._draw()
        self.lb.selection_set(pos)
        self.lb.see(pos)

    def set_name(self):
        i = self._selected_index()
        if i is None:
            return
        saves.set_label(self.save.chapter_key, i, self.name_e.get())
        pos = self.lb.curselection()[0]
        self._draw()
        self.lb.selection_set(pos)

        # cheat-engine style: search, change it in game, search again
    def find(self, narrow):
        if not self.save:
            return
        v = self.find_e.get().strip()
        if not v:
            return
        hits = self.save.find_value(v)
        if narrow and self.hits is not None:
            hits = [h for h in hits if h in set(self.hits)]
        self.hits = hits
        self.hits_lbl.config(text=f"{len(hits)} MATCH(ES)")
        self._draw()

    def clear_find(self):
        self.hits = None
        self.hits_lbl.config(text="")
        if self.save:
            self._draw()

    def write(self):
        if not self.save or not self.save.dirty:
            self.app.say("No changes to write.")
            return
        try:
            self.save.write()
        except Exception as exc:
            theme.error(self.app.root, "Can't write", str(exc))
            return
        self._draw()
        self.app.say("Save written. A backup was made first.")
