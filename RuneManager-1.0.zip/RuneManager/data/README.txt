Your settings, download buttons (catalog.json) and secret presets
are saved here. Put background.png here to use your own backdrop.
